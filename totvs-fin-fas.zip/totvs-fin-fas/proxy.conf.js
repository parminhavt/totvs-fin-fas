const PROXY_CONFIG = [
  {
      context: [
          "/totvs-rest",
          "/totvs-login"
      ],
      target: "http://servidorjboss:8280",
      secure: false,
      changeOrigin: true,
      logLevel: "debug",
      autoRewrite: true
  }, {
      context: [
          "/josso",
          "/dts/datasul-rest"
      ],
      target: "http://vigia:8480",
      secure: false,
      changeOrigin: true,
      logLevel: "debug",
      autoRewrite: true,
      headers: {
          //Cookie: "JOSSO_SESSIONID=COOKIE_1; JSESSIONID=COOKIE_2;"
          Authorization: "Basic c3VwZXI6c3N6a0AxMjM=" /*super*/
        // Authorization: "Basic cm9kcmlnby5iZXR0OlRvdHZzQDEyMw=="  /*rodrigo.bett*/
      }
  }
]

module.exports = PROXY_CONFIG;
