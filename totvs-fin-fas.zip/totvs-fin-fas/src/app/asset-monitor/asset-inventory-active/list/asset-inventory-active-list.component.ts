import { Component, OnInit, OnDestroy, ViewChild, OnChanges } from '@angular/core';
import { forkJoin, Subscription } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';

import { PoPageDynamicTableComponent, PoPageDynamicTableCustomAction, PoPageDynamicTableFilters } from '@po-ui/ng-templates';
//import { AssetIntegrationMonitorService } from '../../shared/services/asset-integration-monitor.service';
import { AssetInventoryActiveService } from '../../../shared/services/asset-inventory-active.service';
import { PoBreadcrumb, PoDialogService, PoI18nService, PoNotificationService } from '@po-ui/ng-components';
import { BreadcrumbControlService } from 'dts-backoffice-util';
//import { IAssetIntegrationMonitor, AssetIntegrationMonitor } from '../../shared/model/asset-integration-monitor.model';
import { IAssetInventoryActive, AssetInventoryActive } from '../../../shared/model/asset-inventory-active.model';

import { KeepFiltersService } from '../../../shared/services/keep-filters.service';
import { valuesFromObject } from '@po-ui/ng-components/lib/utils/util';
import { IAssetTransferParams } from '../../../shared/model/asset-transfer-params.model';

@Component({
  selector: 'app-asset-inventory-active-list',
  templateUrl: './asset-inventory-active-list.component.html'
})
export class AssetInventoryActiveListComponent implements OnInit, OnDestroy {

  @ViewChild('pageDynamicTable', { static: false }) pageDynamicTable: PoPageDynamicTableComponent;

  breadcrumb: PoBreadcrumb;
  literals: any = {};
  readonly documentType = 'invetory';

  constructor(
    private router: Router,
    private service: AssetInventoryActiveService,
    private keepFiltersService: KeepFiltersService,
    private breadcrumbControlService: BreadcrumbControlService,
    private activatedRoute: ActivatedRoute,
    private thfI18nService: PoI18nService,
    private poNotification: PoNotificationService,
    private poDialogService: PoDialogService
  ) { }

  private monitorSubscription$: Subscription;
  public pageCustomActions: Array<PoPageDynamicTableCustomAction>;
  public metadata: any;
  private interval: any;



  ngOnInit(): void {

    forkJoin([
      this.thfI18nService.getLiterals(),
      this.thfI18nService.getLiterals({ context: 'assetInventoryActive' })
    ]).subscribe(literals => {
      literals.map(item => Object.assign(this.literals, item));
      this.getMetadata();
    });
  }

  // tslint:disable-next-line:use-lifecycle-interface
  ngDoCheck(): void { // executa quando ocorrer a detecção de alterações
    if (this.metadata) {
      this.saveFilters();
    }
  }

  private saveFilters() {
    this.keepFiltersService.start();
    this.keepFiltersService.setDocument(this.documentType);
    this.keepFiltersService.savePageDynamicTableFilters(this.pageDynamicTable);

  }

  onClickButton() {

  }

  getMetadata() {
    this.monitorSubscription$ = this.service.getMetadataList().subscribe((metad: any) => {
      this.keepFiltersService.updateMetadataInitials(this.documentType, metad);
      this.metadata = metad;
      if (this.metadata) {
        this.setupComponents();
      }
    });
  }

  private detail(request: IAssetInventoryActive): void {

    sessionStorage.setItem('Monitor_request', request.inventorySequence.toString());
    this.router.navigate(['assetInventoryActive/detail']);
  }

  private move(request: IAssetInventoryActive): void {
    const retireRequest = Array<string>();
  //  retireRequest[0] = request.requestIdSequence.toString();
   // sessionStorage.setItem('Movement_request', JSON.stringify(retireRequest));
   /* if (request.statusRequest !== 'Pendente') {
      this.poNotification.warning(this.literals['requestIsNotPending']);
    } else {
      if (request.operationRequest === 'Baixa') {
        this.router.navigate(['assetIntegrationMonitor/retirement']);
      }
      if (request.operationRequest === 'Transferência') {
        this.router.navigate(['assetIntegrationMonitor/transfer']);
      }
    }*/

  }

  private updateFilters(): void {
    this.interval = setInterval(() => { // aguarda ate que carregue pageDynamicTable.filters
      if (this.pageDynamicTable && this.pageDynamicTable.filters) {
        clearInterval(this.interval);
        this.pageDynamicTable.filters.forEach(campoFiltro => {
          if (campoFiltro.property === 'requestPlanCostCenter') {
            campoFiltro.validate = this.onValidateCostCenter.bind(this);
          }

          if (campoFiltro.property === 'assetAccount') {
            campoFiltro.validate = this.onValidateAsset.bind(this);

            /*if (localStorage.getItem('accountAsset')) {
              campoFiltro.initValue = localStorage.getItem('accountAsset');
            }*/
          }
        });
      }
    }, 60);
  }

  private onValidateCostCenter(changeValue): void {
    let centroCusto: PoPageDynamicTableFilters;
    this.pageDynamicTable.filters.forEach(campoFiltro => {
      if (campoFiltro.property === 'requestCostCenter') {
        centroCusto = campoFiltro;
      }

    });
    this.pageDynamicTable.filters.forEach(campoFiltro => {
      if (campoFiltro.property === 'requestPlanCostCenter') {
        centroCusto.params = { 'planCostCenter': changeValue.value, 'convertToBase64': 'no' };
      }
    });
  }

  private onValidateAsset(changeValue): void {
    let assetAccount: PoPageDynamicTableFilters;
    this.pageDynamicTable.filters.forEach(campoFiltro => {
      if (campoFiltro.property === 'desAssetSeqNumber') {
        assetAccount = campoFiltro;
      }

    });
    this.pageDynamicTable.filters.forEach(campoFiltro => {
      if (campoFiltro.property === 'assetAccount') {
        assetAccount.params = { 'assetCode': changeValue.value };
      }
    });
  }

  private updateFields(): void {
    this.metadata.fields.forEach(field => {
      if (field.property === 'detail') {
        field.action = (value, row) => this.detail(value);
      }
      if (field.property === 'move') {
        field.action = (value, row) => this.move(value);

      }

      if (field.property === 'error') {
        field.action = (value, row) => this.getError(value);

      }
    });
  }

  private getError(request: IAssetInventoryActive): void {

    this.poDialogService.alert({
      title: this.literals['error'],
      message: request.errorDescription
  });

  }


  private moveAssets(request: Array<IAssetInventoryActive>): void {
    let validOperation = false;
    const retireRequest = Array<string>();
    /*if (request[0].operationRequest === 'Baixa') {
      request.find((item) => {
        if (item.operationRequest !== 'Baixa') {
          this.poNotification.warning(this.literals['sameTypeRequest']);
          validOperation = true;
        }
      });
      if (!validOperation) {
        request.forEach(id => {
          if (id.statusInventory === 'Pendente') {
            retireRequest.push(id.inventorySequence.toString());
          }
        });


        sessionStorage.setItem('Movement_request', JSON.stringify(retireRequest));
        this.router.navigate(['assetIntegrationMonitor/retirement']);
      }
    }*/

    /*if (request[0].operationRequest === 'Transferência') {
      request.find((item) => {
        if (item.operationRequest !== 'Transferência') {
          this.poNotification.warning(this.literals['sameTypeRequest']);
          validOperation = true;
        }
      });
      if (!validOperation) {
        request.forEach(id => {
          if (id.statusInventory === 'Pendente') {
            retireRequest.push(id.requestIdSequence.toString());
          }
        });
        sessionStorage.setItem('Movement_request', JSON.stringify(retireRequest));
        this.router.navigate(['assetIntegrationMonitor/transfer']);
      }
    }*/
  }

  private moveRequests(): void {
    this.pageCustomActions = [];
    const actionMove = {
      label: this.literals['newInventory'],
      action: this.moveAssets.bind(this),
     // selectable: true,
    };

    this.pageCustomActions.push(actionMove);
  }

  private setupComponents(): void {

    this.updateFilters(); /* Atualiza os filtros avançados com os parâmetros selecionados*/
    this.updateFields();  /* Atualiza o campo de detalhe/movimentar com a ação de click passando como parâmetro a linha selecionada */
    this.moveRequests();


    //this.breadcrumbControlService.addBreadcrumb(this.literals['assetInventoryActive'], this.activatedRoute);
    //this.breadcrumb = this.breadcrumbControlService.getBreadcrumb();
  }

  ngOnDestroy(): void {

    if (this.interval) { clearInterval(this.interval); }
    if (this.monitorSubscription$) { this.monitorSubscription$.unsubscribe(); }
  }
}
