import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AssetInventoryActiveComponent } from './asset-inventory-active.component';
import { AssetInventoryActiveDetailComponent } from './detail/asset-inventory-active-detail.component';
import { AssetInventoryActiveListComponent } from './list/asset-inventory-active-list.component';

const routes: Routes = [
  {
      path: '',
      component: AssetInventoryActiveComponent,
      children: [
        {
          path: '',
          component: AssetInventoryActiveListComponent
        }        ,
        {
          path: 'detail',
          component: AssetInventoryActiveDetailComponent
        }
      ]
      }
    ];


@NgModule({
      imports: [RouterModule.forChild(routes)],
      exports: [RouterModule]
  })

  export class AssetInventoryActiveRoutingModule { }
