import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { PoModule } from '@po-ui/ng-components';
import { PoI18nPipe } from '@po-ui/ng-components';

import { AssetInventoryActiveRoutingModule } from './asset-inventory-active-routing.module';
//import { AssetInventoryActiveComponent } from './asset-inventory-active.component';
import { CompanyService } from '../../shared/services/company.service';
import { AssetInventoryActiveService } from '../../shared/services/asset-inventory-active.service';
//import { AssetIntegrationMonitorService } from '../../shared/services/asset-integration-monitor.service';
import { AssetInventoryActiveListComponent } from './list/asset-inventory-active-list.component';
import { PoTemplatesModule } from '@po-ui/ng-templates';
import { AssetInventoryActiveDetailComponent } from './detail/asset-inventory-active-detail.component';
import { AssetInventoryActiveDetailService } from '../../shared/services/asset-inventory-active-detail.service';
//import { AssetIntegrationMonitorRetirementComponent } from './retirement/asset-integration-monitor-retirement.component';
import { CurrencyService } from '../../shared/services/currency.service';
import { AccountingScenarioService } from '../../shared/services/accounting-scenario.service';
import { DemobilizationReasonService } from '../../shared/services/demobilization-reason.service';
import { AssetRetirementService } from '../../shared/services/asset-retirement.service';
import { PersonService } from '../../shared/services/person.service';
import { DeliveryAddressService } from '../../shared/services/delivery-address.service';
//import { AssetIntegrationMonitorTransferComponent } from './transfer/asset-integration-monitor-transfer.component';
import { CostCenterPlanService } from '../../shared/services/cost-center-plan.service';
import { AssetTransferService } from '../../shared/services/asset-transfer.service';
import { RpwService } from '../../shared/services/rpw.service';
import { ParamMonitorService } from '../../shared/services/param-monitor.service';
import { VersionProgramService } from '../../shared/services/version-program.service';
import { CostCenterService } from '../../shared/services/cost-center.service';
import { BranchService } from '../../shared/services/branch.service';
import { LocationService } from '../../shared/services/location.service';
import { KeepFiltersService } from './../../shared/services/keep-filters.service';

@NgModule({
  imports: [
      CommonModule,
      PoModule,
      FormsModule,
      PoTemplatesModule,
      HttpClientModule,
      AssetInventoryActiveRoutingModule

  ],
  declarations: [
     // AssetInventoryActiveComponent,
      AssetInventoryActiveListComponent,
      AssetInventoryActiveDetailComponent,
      //AssetIntegrationMonitorRetirementComponent,
      //AssetIntegrationMonitorTransferComponent
  ],
  exports: [
     // AssetIntegrationMonitorComponent,
   //  AssetInventoryActiveComponent,
      AssetInventoryActiveListComponent,
      AssetInventoryActiveDetailComponent,
     // AssetIntegrationMonitorRetirementComponent,
     // AssetIntegrationMonitorTransferComponent
  ],
  providers: [
      PoI18nPipe,
      CompanyService,
      AssetInventoryActiveService,
     // AssetIntegrationMonitorService,
      AssetInventoryActiveDetailService,
      CurrencyService,
      AccountingScenarioService,
      DemobilizationReasonService,
      AssetRetirementService,
      PersonService,
      DeliveryAddressService,
      CostCenterPlanService,
      LocationService,
      AssetTransferService,
      RpwService,
      ParamMonitorService,
      VersionProgramService,
      CostCenterService,
      KeepFiltersService,
      BranchService
  ],
})
export class AssetInventoryActiveModule { }
