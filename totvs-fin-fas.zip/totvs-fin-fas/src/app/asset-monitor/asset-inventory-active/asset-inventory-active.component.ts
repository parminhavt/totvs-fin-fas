import { IParamMonitor } from '../../shared/model/param-monitor.model';
import { ParamMonitorService } from '../../shared/services/param-monitor.service';
import { Component, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { PoI18nService, PoI18nPipe, PoPopupAction, PoModalAction, PoModalComponent, PoTableColumn, PoNotificationService } from '@po-ui/ng-components';
import { forkJoin, Subscription } from 'rxjs';
import { PoToolbarAction } from '@po-ui/ng-components';
import { CompanyService } from '../../shared/services/company.service';
import { ICompany } from '../../shared/model/company.model';
import { RpwService } from '../../shared/services/rpw.service';
import { ParamMonitor } from '../../shared/model/param-monitor.model';
import { FieldValidationUtil } from 'dts-backoffice-util';


@Component({
    selector: 'app-asset-inventory-active',
    templateUrl: './asset-inventory-active.component.html',
    styleUrls: ['./asset-inventory-active.component.css']
})
export class AssetInventoryActiveComponent implements OnInit, OnDestroy {

  @ViewChild('target', { read: ElementRef, static: true }) targetRef: ElementRef;

    companySubscription$: Subscription;
    paramMonitorSubscription$: Subscription;

    fieldValidationUtil: FieldValidationUtil;

    literals: any = {};
    profileActions: Array<PoToolbarAction> = [];
    currentCompany: string;
    notificationActions: Array<PoToolbarAction>;
    actions: Array<PoToolbarAction> = [];

    popupActions: Array<PoPopupAction>;
    closeAction: PoModalAction;
    saveAction: PoModalAction;

    rpwFilterParams = { hideLoading: true, allow: true};
    rpwServerColumns: Array<PoTableColumn>;
    paramMonitor: IParamMonitor = new ParamMonitor();
    updateServer = false;

    @ViewChild(PoModalComponent, { static: true }) parametersModal: PoModalComponent;

    constructor(
        private poI18nService: PoI18nService,
        private poI18nPipe: PoI18nPipe,
        private poNotification: PoNotificationService,
        private companyService: CompanyService,
        public  rpwService: RpwService,
        private paramMonitorService: ParamMonitorService,
        private router: Router
    ) { }

    ngOnInit(): void {
        forkJoin([
            this.poI18nService.getLiterals(),
            this.poI18nService.getLiterals({ context: 'assetInventoryActive' })
        ]).subscribe(literals => {
            literals.map(item => Object.assign(this.literals, item));
            this.fieldValidationUtil = new FieldValidationUtil(this.poNotification, this.poI18nPipe, this.literals);
            this.companySubscription$ = this.companyService
                .getCurrentCompany()
                .subscribe((response: ICompany) => {
                    this.currentCompany = response.companyCode;

                    this.profileActions = [
                        { icon: 'po-icon-company', label: this.literals['company'] + ' ' + this.currentCompany },

                      ];
                });

            this.setupComponents();
            this.getServer();
        });
    }

    public rpwFieldFormat(value: any) {
      return `${value.code} - ${value.name}`;
    }

    private saveParameters(item: IParamMonitor): void {
      if (this.onValidFields()) {
        if (this.updateServer) {
          this.paramMonitorSubscription$ = this.paramMonitorService
          .update(item)
          .subscribe(() => {
            this.poNotification.success(this.literals['updatedMessage']);
            this.parametersModal.close();
          });
        } else {
          this.paramMonitorSubscription$ = this.paramMonitorService
          .create(item)
          .subscribe((response: IParamMonitor) => {
            if (response && response.serverCode) {
              this.paramMonitor = response;
            }
            this.poNotification.success(this.literals['updatedMessage']);
            this.updateServer = true;
            this.parametersModal.close();
          });
        }

      }
    }


    openPopup(item: PoToolbarAction): void {
      // Criar o popup com as notificações que virão do RPW
    }

    openParamsModal(): void {
      this.parametersModal.open();

    }

    private getServer(): void {
      this.updateServer = false;
      this.paramMonitorSubscription$ = this.paramMonitorService.getById('', '').subscribe(
        (response: IParamMonitor) => {
          if (response && response.serverCode) {
            this.updateServer = true;
            this.paramMonitor = response;
          }
        }
      );
    }

    private onValidFields(): boolean {
      let isOk = true;

      if (!this.fieldValidationUtil.vldFieldCharacter('executionServer',
          this.paramMonitor.serverCode)) { isOk = false; }

      return isOk;
  }

  public newInventory() {

  }

  public disabledButton() {
    /*
    if (!this.value.rpwServer ||
        (!this.value.exportNotDefaultRecord && !this.value.exportDefaultRecord)){
      return true;
    }else{
      return false;
    }*/
    return false;
  }

    private setupComponents(): void {

        this.notificationActions = [
            { icon: 'po-icon-message', label: this.literals['notifications'], action: item => this.openPopup(item) },
            { icon: 'po-icon-message', label: this.literals['notifications'], action: item => this.openPopup(item) }

        ];

        this.actions = [
          { icon: 'po-icon-settings', label: this.literals['generalParams'], action: () => this.openParamsModal() }
        ];

        this.closeAction = { label: this.literals['close'], action: () => { this.parametersModal.close(); } };

        this.saveAction = { label: this.literals['save'], action: () => { this.saveParameters(this.paramMonitor); } };

        this.rpwServerColumns = [
          { property: 'code', label: this.literals['code'], type: 'number' },
          { property: 'name', label: this.literals['name'], type: 'string' }
      ];


    }

    ngOnDestroy(): void {
      if (this.companySubscription$) { this.companySubscription$.unsubscribe(); }
    }
}
