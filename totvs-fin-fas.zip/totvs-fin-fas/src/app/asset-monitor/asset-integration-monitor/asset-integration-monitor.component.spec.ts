import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { AssetIntegrationMonitorComponent } from './asset-integration-monitor.component';


describe('AssetIntegrationMonitorComponent', () => {
  let component: AssetIntegrationMonitorComponent;
  let fixture: ComponentFixture<AssetIntegrationMonitorComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AssetIntegrationMonitorComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetIntegrationMonitorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
