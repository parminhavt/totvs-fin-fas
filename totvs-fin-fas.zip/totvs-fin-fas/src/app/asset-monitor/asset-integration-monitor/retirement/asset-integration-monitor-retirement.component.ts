import { Currency } from '../../../shared/model/currency.model';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { forkJoin, Subscription } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';

import {
  PoBreadcrumb, PoDisclaimer, PoI18nPipe, PoI18nService, PoLookupColumn, PoNotificationService, PoPageAction,
  PoRadioGroupOption, PoSelectOption, PoTableColumn
} from '@po-ui/ng-components';
import { BreadcrumbControlService, DisclaimerUtil, FieldValidationUtil, TotvsResponse } from 'dts-backoffice-util';
import { AssetRetirementParams, IAssetRetirementParams } from '../../../shared/model/asset-retirement-params.model';
import { DemobilizationReasonService } from '../../../shared/services/demobilization-reason.service';
import { CurrencyService } from '../../../shared/services/currency.service';
import { AccountingScenarioService } from '../../../shared/services/accounting-scenario.service';
import { IDemobilizationReason } from '../../../shared/model/demobilization-reason.model';
import { IAccountingScenario } from '../../../shared/model/accounting-scenario.model';
import { ICurrency } from '../../../shared/model/currency.model';
import { AssetRetirementService } from '../../../shared/services/asset-retirement.service';
import { PersonService } from '../../../shared/services/person.service';
import { RetirementParams } from '../../../shared/model/retirement-params.model';
import { RpwService } from '../../../shared/services/rpw.service';
import { ParamMonitorService } from '../../../shared/services/param-monitor.service';
import { IParamMonitor } from '../../../shared/model/param-monitor.model';
import { VersionProgramService } from '../../../shared/services/version-program.service';
import { IVersionProgram } from '../../../shared/model/version-program.model';


@Component({
  selector: 'app-asset-integration-monitor-retirement',
  templateUrl: './asset-integration-monitor-retirement.component.html'
})
export class AssetIntegrationMonitorRetirementComponent implements OnInit, OnDestroy {

  literals: any = {};
  pageActions: Array<PoPageAction>;
  title: string;
  retireTitle: string;
  pageBreadcrumb: PoBreadcrumb;
  fieldValidationUtil: FieldValidationUtil;

  monitorSubscription$: Subscription;
  retirement = new RetirementParams();
  retirementAux = new RetirementParams();
  radioGroupOptions: Array<PoRadioGroupOption>;
  retireOptions: Array<PoSelectOption>;
  scenarioOptions: Array<PoSelectOption>;
  currencyOptions: Array<PoSelectOption>;
  personOptions: Array<PoSelectOption>;
  addressOptions: Array<PoSelectOption>;
  demobReasonOptions: Array<PoSelectOption>;
  personTypeOptions: Array<PoRadioGroupOption>;
  tableActions: Array<PoPageAction>;
  assetColumns: Array<PoTableColumn>;
  zoomPerson: Array<PoLookupColumn>;
  zoomAddress: Array<PoLookupColumn>;

  disclaimers: Array<PoDisclaimer> = [];
  disclaimerUtil: DisclaimerUtil;
  filterParamsPerson = { personType: 1 };

  tableTitle: string;

  jsonObject: any = {};
  rpwServer: string;
  userRpw: string;
  programVersion: string;

  constructor(
    private activatedRoute: ActivatedRoute,
    private breadcrumbControlService: BreadcrumbControlService,
    private poI18nPipe: PoI18nPipe,
    private thfI18nService: PoI18nService,
    private thfNotification: PoNotificationService,
    private router: Router,
    private poNotification: PoNotificationService,
    private demobReasonService: DemobilizationReasonService,
    private currencyService: CurrencyService,
    private scenarioService: AccountingScenarioService,
    private assetRetirementService: AssetRetirementService,
    public personService: PersonService,
    private rpwService: RpwService,
    private paramMonitorService: ParamMonitorService,
    private versionProgramService: VersionProgramService
  ) { }



  ngOnInit(): void {

    forkJoin([
      this.thfI18nService.getLiterals(),
      this.thfI18nService.getLiterals({ context: 'assetIntegrationMonitorRetirement' })
    ]).subscribe(literals => {
      literals.map(item => Object.assign(this.literals, item));
      this.disclaimerUtil = new DisclaimerUtil(this.poNotification, this.poI18nPipe, this.literals);
      this.fieldValidationUtil = new FieldValidationUtil(this.thfNotification, this.poI18nPipe, this.literals);
      this.setupComponents();

    });
  }

  fieldPersonFormat(value) {
    return `${value.personNumber} - ${value.personName}`;
  }

  fieldAddressFormat(value) {
    return `${value.address}`;
  }


  private return(): void {
    this.router.navigate([this.breadcrumbControlService.getPrevRouter()]);
  }

  /* Valida os campos dos parâmetros */
  private onValidFields(): boolean {
    let isOk = true;

    if (this.retirement.assetRetirementParams.length === 0) {
      this.poNotification.error(this.literals['emptyAssetSelect']);
      isOk = false;
    }

    if (!this.fieldValidationUtil.vldFieldDate('transactionDate', this.retirement.transactionDate)) { isOk = false; }

    if (!this.fieldValidationUtil.vldFieldNumber('retirementReason', this.retirement.retirementReason)) { isOk = false; }

    if (!this.fieldValidationUtil.vldFieldCharacter('demobReason', this.retirement.demobReason)) { isOk = false; }

    if (this.retirement.idiRetirementType === 1) {
      if (!this.fieldValidationUtil.vldFieldNumber('originalValue', this.retirement.originalValue, true, false)) { isOk = false; }
      if (!this.fieldValidationUtil.vldFieldCharacter('scenario', this.retirement.scenario)) { isOk = false; }
      if (!this.fieldValidationUtil.vldFieldCharacter('economicIndicator', this.retirement.economicIndicator)) { isOk = false; }

    }

    if (this.retirement.idiRetirementType === 3) {
      if (!this.fieldValidationUtil.vldFieldNumber('quantityValue', this.retirement.quantityValue, true, false)) { isOk = false; }
    }

    if (this.retirement.idiRetirementType === 2) {
      if (!this.fieldValidationUtil.vldFieldNumber('percentageValue', this.retirement.percentageValue, true, false)) { isOk = false; }
    }

    return isOk;
  }

  private getRpwName(): void {

    this.monitorSubscription$ = this.paramMonitorService
      .getById(' ', ' ').subscribe((resp: IParamMonitor) => {
        if (resp) {
          this.rpwServer = resp.serverCode;
          this.userRpw = resp.userCode;

          this.retirementAux = Object.assign({}, this.retirement);

          this.monitorSubscription$ = this.assetRetirementService
            .searchPreviousRequests(this.retirementAux)
            .subscribe(() => {
              this.schedule();
            }, (error: any) => {
              this.thfNotification.error(this.literals['rpwRetirementError']);
            });

          /*
          this.retirementAux.assetRetirementParams = [];

          this.retirement.assetRetirementParams.forEach(assetRetirementParamItem => {
            this.retirementAux.assetRetirementParams[0] = assetRetirementParamItem;
            this.schedule();
          });
          */

        }
      }, (erro: any) => {
        this.poNotification.error(this.literals['errorFindRpwServer']);
      });

  }
  private getProgramVersion(): void {

    this.monitorSubscription$ = this.versionProgramService
      .get('rnl_bem_pat_baixa').subscribe((resp: IVersionProgram) => {
        if (resp) {
          this.programVersion = resp.versionCode;
          this.getRpwName();
        }
      }, (erro: any) => {
        this.poNotification.error(this.literals['errorFindProgramVersion']);
      });
  }

  public schedule() {

    this.jsonObject = {};
    this.jsonObject.status = 'active';
    this.jsonObject.processID = 'rnl_bem_pat_baixa';
    this.jsonObject.recurrent = false;
    this.jsonObject.user = this.userRpw;
    this.jsonObject.executionParameter = {};

    this.jsonObject.executionParameter.parametros = [];
    this.jsonObject.executionParameter.parametros[0] = { 'chave': 'rpwServer', 'valor': this.rpwServer };
    this.jsonObject.executionParameter.parametros[1] = { 'chave': 'RPW_PROGRAM', 'valor': 'tar_baixa' };
    this.jsonObject.executionParameter.parametros[2] = { 'chave': 'RPW_PRG_EMS5', 'valor': 'yes' };
    this.jsonObject.executionParameter.parametros[3] = { 'chave': 'RPW_PRG_ESTILO', 'valor': '30' },
    this.jsonObject.executionParameter.parametros[4] = { 'chave': 'RPW_PRG_VERS', 'valor': this.programVersion };
    this.jsonObject.executionParameter.parametros[5] = {};
    this.jsonObject.executionParameter.parametros[5].parametros_negocio = [{ 'chave': '', 'valor': '' }];


    this.rpwService.rpwExecute(this.jsonObject, true).subscribe(resp => {

      if (resp.jobScheduleID === '') {
        this.poNotification.error(this.literals['errorCreateRpwID']);
      } else {
        this.retirementAux.jobScheduleID = resp.jobScheduleID;
        this.executeRetirement();
      }
    });
  }

  private executeRetirement(): void {
    this.monitorSubscription$ = this.assetRetirementService
      .executeRetirement(this.retirementAux)
      .subscribe(() => {
          this.pageActions[0].disabled = false;
          this.thfNotification.success(this.literals['rpwRetirementSuccess']);
          this.return();
      }, (error: any) => {
        this.pageActions[0].disabled = false;
        this.thfNotification.error(this.literals['rpwRetirementError']);
      });
  }


  private assetMovement(): void {

    if (this.onValidFields()) {
      this.getProgramVersion();
    }
  }

  private addDisclaimer(disclaimerListItem: Array<PoDisclaimer>): void {
    if (!disclaimerListItem) { return; }

    disclaimerListItem.forEach(disclaimerItem => {
      this.disclaimers.push(disclaimerItem);
    });
  }


  private loadRequestDetails(): void {
    const id = JSON.parse(sessionStorage.getItem('Movement_request'));
    if (id.length === 1) {
      this.tableTitle = this.literals['fixedAsset'];
      this.retireTitle = this.literals['assetTitle'];
    } else {
      this.tableTitle = this.literals['fixedAssets'];
      this.retireTitle = this.literals['assetsTitle'];
    }

    this.retirement.assetRetirementParams = [];

    id.forEach(request => {

      this.disclaimers = [];
      this.addDisclaimer([
        this.disclaimerUtil.makeDisclaimer('idRequest', request)
      ]);

      this.monitorSubscription$ = this.assetRetirementService
        .query(this.disclaimers, 0, 9999, true)
        .subscribe((response: TotvsResponse<IAssetRetirementParams>) => {
          response.items.forEach(param => {
            this.retirement.transactionDate = param.date;
            this.retirement.economicIndicator = param.currency;
            this.retirement.assetRetirementParams.push(param);

            if (param.quantity !== 0 && param.quantity !== null) {
              this.retirement.quantityValue = param.quantity;
              this.retirement.idiRetirementType = 3;
            } else if (param.percentage !== 0 && param.percentage !== null) {
              this.retirement.percentageValue = param.percentage;
              this.retirement.idiRetirementType = 2;
            } else {
              this.retirement.originalValue = param.value;
              this.retirement.idiRetirementType = 1;
            }
          });
        });
    });

  }

  private loadServices(): void {
    this.scenarioOptions = [];
    this.currencyOptions = [];
    this.demobReasonOptions = [];

    this.monitorSubscription$ = this.scenarioService
      .query([], 0, 9999, true)
      .subscribe((response: TotvsResponse<IAccountingScenario>) => {
        this.scenarioOptions.length = 0;
        response.items.forEach(scenario => {
          this.scenarioOptions.push({
            label: `${scenario.accountingScenarioCode} - ${scenario.accountingScenarioDescription}`,
            value: scenario.accountingScenarioCode
          });
        });
      }, (err: any) => {
      });

    this.monitorSubscription$ = this.currencyService
      .query([], 0, 9999, true)
      .subscribe((response: TotvsResponse<ICurrency>) => {
        this.currencyOptions.length = 0;
        response.items.forEach(currency => {
          this.currencyOptions.push({
            label: `${currency.code} - ${currency.description}`,
            value: currency.code
          });
        });
      }, (err: any) => {
      });

    this.monitorSubscription$ = this.demobReasonService
      .query([], 0, 9999, true)
      .subscribe((response: TotvsResponse<IDemobilizationReason>) => {
        this.demobReasonOptions.length = 0;
        response.items.forEach(reason => {
          this.demobReasonOptions.push({
            label: `${reason.reasonCode} - ${reason.descReason}`,
            value: reason.reasonCode
          });
        });
      }, (err: any) => {
      });
  }

  public onChangePersonType(type: number) {
    if (type === 1) {
      this.filterParamsPerson.personType = 1;
    } else {
      this.filterParamsPerson.personType = 2;
    }
  }

  public onChangeRetireType(type: string): void {

    this.retirement.originalValue = 0;
    this.retirement.quantityValue = 0;
    this.retirement.percentageValue = 0;
  }


  private removeAsset(asset: IAssetRetirementParams): void {

    const idx = this.retirement.assetRetirementParams.indexOf(asset);
    this.retirement.assetRetirementParams.splice(idx, 1);
  }

  private setupComponents(): void {

    this.breadcrumbControlService.addBreadcrumb(this.literals['requestMovement'], this.activatedRoute);
    this.pageBreadcrumb = this.breadcrumbControlService.getBreadcrumb();

    this.pageActions = [
      { label: this.literals['execute'], action: this.assetMovement.bind(this, this.retirement), type: 'default' },
      { label: this.literals['return'], action: this.return.bind(this), type: 'default' }
    ];

    this.retirement.idiRetirementType = 1;

    this.radioGroupOptions = [
      { label: this.literals['byValue'], value: 1 },
      { label: this.literals['byPercent'], value: 2 },
      { label: this.literals['byAmount'], value: 3 }
    ];

    this.personTypeOptions = [
      { label: this.literals['natural'], value: 1 },
      { label: this.literals['legal'], value: 2 }
    ];

    this.filterParamsPerson.personType = 1;


    this.retireOptions = [
      { label: this.literals['returnRetire'], value: 1 },
      { label: this.literals['exhaust'], value: 2 },
      { label: this.literals['idle'], value: 3 },
      { label: this.literals['break'], value: 4 },
      { label: this.literals['sale'], value: 5 }
    ];
    this.retirement.retirementReason = 3;

    this.assetColumns = [
      { label: this.literals['assetAccount'], property: 'descAssetAccount', type: 'string' },
      { label: this.literals['fixedAsset'], property: 'desAssetSeqNumber', type: 'string' },
      { label: this.literals['descFixedAsset'], property: 'descFixedAsset', type: 'string' }
    ];

    this.tableActions = [
      { label: this.literals['remove'], action: this.removeAsset.bind(this), icon: 'po-icon po-icon-delete' }
    ];

    this.zoomAddress = [
      { property: 'comporatePerson', label: this.literals['personNumber'], type: 'number', width: '15%' },
      { property: 'address', label: this.literals['address'], type: 'string', width: '30%' },
      { property: 'addressName', label: this.literals['addressName'], type: 'string', width: '35%' },
      { property: 'country', label: this.literals['country'], type: 'string', width: '10%' }
    ];

    this.zoomPerson = [
      { property: 'personNumber', label: this.literals['personNumber'], type: 'number', width: '15%' },
      { property: 'personName', label: this.literals['personName'], type: 'string', width: '50%' },
      { property: 'country', label: this.literals['country'], type: 'string', width: '10%' },
      { property: 'federalID', label: this.literals['federalID'], type: 'string', width: '35%' }
    ];

    this.loadServices();

    this.loadRequestDetails();



  }

  ngOnDestroy(): void {
    if (this.monitorSubscription$) {
      this.monitorSubscription$.unsubscribe();
    }
  }
}
