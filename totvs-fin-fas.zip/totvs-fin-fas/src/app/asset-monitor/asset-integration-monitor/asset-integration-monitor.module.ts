import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { PoModule } from '@po-ui/ng-components';
import { PoI18nPipe } from '@po-ui/ng-components';
import { AssetIntegrationMonitorRoutingModule } from './asset-integration-monitor-routing.module';
import { AssetIntegrationMonitorComponent } from './asset-integration-monitor.component';
import { CompanyService } from '../../shared/services/company.service';
import { AssetIntegrationMonitorService } from '../../shared/services/asset-integration-monitor.service';
import { AssetIntegrationMonitorListComponent } from './list/asset-integration-monitor-list.component';
import { PoTemplatesModule } from '@po-ui/ng-templates';
import { AssetIntegrationMonitorDetailComponent } from './detail/asset-integration-monitor-detail.component';
import { AssetIntegrationMonitorDetailService } from '../../shared/services/asset-integration-monitor-detail.service';
import { AssetIntegrationMonitorRetirementComponent } from './retirement/asset-integration-monitor-retirement.component';
import { CurrencyService } from '../../shared/services/currency.service';
import { AccountingScenarioService } from '../../shared/services/accounting-scenario.service';
import { DemobilizationReasonService } from '../../shared/services/demobilization-reason.service';
import { AssetRetirementService } from '../../shared/services/asset-retirement.service';
import { PersonService } from '../../shared/services/person.service';
import { DeliveryAddressService } from '../../shared/services/delivery-address.service';
import { AssetIntegrationMonitorTransferComponent } from './transfer/asset-integration-monitor-transfer.component';
import { CostCenterPlanService } from '../../shared/services/cost-center-plan.service';
import { AssetTransferService } from '../../shared/services/asset-transfer.service';
import { RpwService } from '../../shared/services/rpw.service';
import { ParamMonitorService } from '../../shared/services/param-monitor.service';
import { VersionProgramService } from '../../shared/services/version-program.service';
import { CostCenterService } from '../../shared/services/cost-center.service';
import { BranchService } from '../../shared/services/branch.service';
import { LocationService } from '../../shared/services/location.service';
import { KeepFiltersService } from '../../shared/services/keep-filters.service';

@NgModule({
  imports: [
      CommonModule,
      PoModule,
      FormsModule,
      PoTemplatesModule,
      HttpClientModule,
      AssetIntegrationMonitorRoutingModule

  ],
  declarations: [
     // AssetIntegrationMonitorComponent,
      AssetIntegrationMonitorListComponent,
      AssetIntegrationMonitorDetailComponent,
      AssetIntegrationMonitorRetirementComponent,
      AssetIntegrationMonitorTransferComponent
  ],
  exports: [
     // AssetIntegrationMonitorComponent,
      AssetIntegrationMonitorListComponent,
      AssetIntegrationMonitorDetailComponent,
      AssetIntegrationMonitorRetirementComponent,
      AssetIntegrationMonitorTransferComponent
  ],
  providers: [
      PoI18nPipe,
      CompanyService,
      AssetIntegrationMonitorService,
      AssetIntegrationMonitorDetailService,
      CurrencyService,
      AccountingScenarioService,
      DemobilizationReasonService,
      AssetRetirementService,
      PersonService,
      DeliveryAddressService,
      CostCenterPlanService,
      LocationService,
      AssetTransferService,
      RpwService,
      ParamMonitorService,
      VersionProgramService,
      CostCenterService,
      KeepFiltersService,
      BranchService
  ],
})
export class AssetIntegrationMonitorModule { }
