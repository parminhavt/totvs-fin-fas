import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AssetIntegrationMonitorComponent } from './asset-integration-monitor.component';
import { AssetIntegrationMonitorDetailComponent } from './detail/asset-integration-monitor-detail.component';
import { AssetIntegrationMonitorListComponent } from './list/asset-integration-monitor-list.component';
import { AssetIntegrationMonitorRetirementComponent } from './retirement/asset-integration-monitor-retirement.component';
import { AssetIntegrationMonitorTransferComponent } from './transfer/asset-integration-monitor-transfer.component';

const routes: Routes = [
  {
      path: '',
      component: AssetIntegrationMonitorComponent,
      children: [
        {
          path: '',
          component: AssetIntegrationMonitorListComponent
        },
        {
          path: 'detail',
          component: AssetIntegrationMonitorDetailComponent
        },
        {
          path: 'retirement',
          component: AssetIntegrationMonitorRetirementComponent
        },
        {
          path: 'transfer',
          component: AssetIntegrationMonitorTransferComponent
        }
      ]
      }
    ];


@NgModule({
      imports: [RouterModule.forChild(routes)],
      exports: [RouterModule]
  })

  export class AssetIntegrationMonitorRoutingModule { }
