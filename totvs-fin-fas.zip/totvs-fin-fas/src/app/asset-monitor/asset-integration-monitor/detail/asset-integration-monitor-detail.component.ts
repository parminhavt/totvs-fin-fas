import { Component, OnInit, OnDestroy } from '@angular/core';
import { forkJoin, Subscription } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';

import { PoBreadcrumb, PoI18nPipe, PoI18nService, PoNotificationService, PoPageAction, PoTableColumn } from '@po-ui/ng-components';
import { BreadcrumbControlService } from 'dts-backoffice-util';
import { AssetIntegrationMonitorDetail,
  IAssetIntegrationMonitorDetail } from '../../../shared/model/asset-integration-monitor-detail.model';
import { AssetIntegrationMonitor, IAssetIntegrationMonitor } from '../../../shared/model/asset-integration-monitor.model';
import { AssetIntegrationMonitorMovements, IAssetIntegrationMonitorMovements } from '../../../shared/model/asset-integration-monitor-movements.model';
import { AssetIntegrationMonitorDetailService } from '../../../shared/services/asset-integration-monitor-detail.service';
import { AssetRetirementParams } from '../../../shared/model/asset-retirement-params.model';

@Component({
  selector: 'app-asset-integration-monitor-detail',
  templateUrl: './asset-integration-monitor-detail.component.html'
})
export class AssetIntegrationMonitorDetailComponent implements OnInit, OnDestroy {

  literals: any = {};
  pageActions: Array<PoPageAction>;
  pageBreadcrumb: PoBreadcrumb;

  monitorSubscription$: Subscription;

  assetDetail: IAssetIntegrationMonitorDetail = AssetIntegrationMonitorDetail.empty();
  assetMovements: Array<IAssetIntegrationMonitorMovements> = new Array<IAssetIntegrationMonitorMovements>();
  requestParams = new AssetRetirementParams();


  assetColums: Array<PoTableColumn>;
  isLoadingMovements: boolean;
  transCalcFixedLabels: any;
  origCalcFixedLabels: any;
  statusColor: string;
  requestId: string;

  constructor(
    private activatedRoute: ActivatedRoute,
    private breadcrumbControlService: BreadcrumbControlService,
    private thfI18nPipe: PoI18nPipe,
    private thfI18nService: PoI18nService,
    private router: Router,
    private detailService: AssetIntegrationMonitorDetailService,
    private poNotification: PoNotificationService
  ) { }



  ngOnInit(): void {

    forkJoin([
      this.thfI18nService.getLiterals(),
      this.thfI18nService.getLiterals({ context: 'assetIntegrationMonitorDetail' })
    ]).subscribe(literals => {
      literals.map(item => Object.assign(this.literals, item));
      this.setupComponents();

    });

  }

  statusRequestLabel(value: number): any {
    let statusReturn: any;
    const statusRequest = AssetIntegrationMonitorDetail.statusRequestLabelList(this.literals);

    statusReturn = statusRequest[0];

    statusRequest.find((item) => {
      if (item.value === value) {
        statusReturn = item;
      }
    });

    return statusReturn;
  }

  operationRequestLabel(value: number): any {
    let operationReturn: any;
    const operationRequest = AssetIntegrationMonitorDetail.operationRequestLabelList(this.literals);
    operationReturn = operationRequest[0];

    operationRequest.find((item) => {
      if (item.value === value) {
        operationReturn = item;
      }
    });

    return operationReturn;
  }


  private return(): void {
    this.router.navigate([this.breadcrumbControlService.getPrevRouter()]);
  }

  private cancelRequest(): void {
    this.monitorSubscription$ = this.detailService
      .cancelRequest(this.assetDetail)
      .subscribe(() => {
          this.poNotification.success(this.literals['cancelRequestSucess']);
          this.loadRequestDetails();
      }, (error: any) => {
          this.poNotification.error(this.literals['cancelRequestError']);
      });

  }

  private assetMovement(): void {
    const retireRequest = Array<string>();
    retireRequest[0] = this.requestId;
    sessionStorage.setItem('Movement_request',  JSON.stringify(retireRequest));
    if (this.assetDetail.operation === 1) {
      this.router.navigate(['assetIntegrationMonitor/retirement']);
    }
    if (this.assetDetail.operation === 2) {
      this.router.navigate(['assetIntegrationMonitor/transfer']);
    }
  }

  private loadRequestDetails(): void {
    this.requestId = sessionStorage.getItem('Monitor_request');
    this.monitorSubscription$ = this.detailService
      .getById(this.requestId).subscribe((detail: IAssetIntegrationMonitorDetail) => {
        this.assetDetail = detail;
        this.assetDetail.operationRequest = this.operationRequestLabel(this.assetDetail.operation).label;
        this.assetDetail.statusRequest = this.statusRequestLabel(this.assetDetail.status).label;
        this.statusColor = this.statusRequestLabel(this.assetDetail.status).color;
        this.assetMovements = this.assetDetail.assetMovements;
        this.isLoadingMovements = false;

        if (this.assetDetail.status === 1){
          this.pageActions[0].disabled = false;
          this.pageActions[1].disabled = false;
        } else {
          this.pageActions[0].disabled = true;
          this.pageActions[1].disabled = true;
        }

      });
  }

  private setupComponents(): void {

    this.breadcrumbControlService.addBreadcrumb(this.literals['requestDetails'], this.activatedRoute);
    this.pageBreadcrumb = this.breadcrumbControlService.getBreadcrumb();

    this.pageActions = [
      { label: this.literals['assetMovement'], action: this.assetMovement.bind(this), type: 'default' },
      { label: this.literals['cancelRequest'], action: this.cancelRequest.bind(this), type: 'danger' },
      { label: this.literals['return'], action: this.return.bind(this), type: 'default' }
    ];

    this.transCalcFixedLabels = AssetIntegrationMonitorMovements.transCalcFixedLabelList(this.literals);
    this.origCalcFixedLabels = AssetIntegrationMonitorMovements.origCalcFixedLabelList(this.literals);

    this.assetColums = [
      { property: 'incorporationSequence', label: this.literals['incorporationSequence'], type: 'number'},
      { property: 'movementDate', label: this.literals['movementDate'], type: 'date' },
      { property: 'idiTransCalcFixed', label: this.literals['transCalcFixed'], type: 'label',  labels: this.transCalcFixedLabels },
      { property: 'idiOrigCalcFixed', label: this.literals['origCalcFixed'], type: 'label', labels: this.origCalcFixedLabels },
      { property: 'originMovementValue', label: this.literals['originMovementValue'], type: 'currency' },
      { property: 'branch', label: this.literals['assetBranch'], type: 'string'},
      { property: 'costCenter', label: this.literals['costCenter'], type: 'string' },
      { property: 'planCostCenter', label: this.literals['planCostCenter'], type: 'string', visible: false },
      { property: 'accountingScenario', label: this.literals['accountingScenario'], type: 'string', visible: false },
      { property: 'economicPurpose', label: this.literals['economicPurpose'], type: 'string', visible: false },
      { property: 'originMovementPercValue', label: this.literals['originMovementPercValue'], type: 'number', visible: false },
      { property: 'originMovementAmount', label: this.literals['originMovementAmount'], type: 'number', visible: false },
      { property: 'businessUnit', label: this.literals['businessUnit'], type: 'string', visible: false }


  ];

    this.loadRequestDetails();

  }

  ngOnDestroy(): void {
    if (this.monitorSubscription$) {
      this.monitorSubscription$.unsubscribe();
    }
  }
}
