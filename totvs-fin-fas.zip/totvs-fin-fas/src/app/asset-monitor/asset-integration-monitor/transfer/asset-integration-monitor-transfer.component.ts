import { Component, OnInit, OnDestroy } from '@angular/core';
import { forkJoin, Subscription } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';

import {
  PoBreadcrumb, PoDisclaimer, PoI18nPipe, PoI18nService, PoLookupColumn, PoNotificationService, PoPageAction,
  PoRadioGroupOption, PoSelectOption, PoTableColumn
} from '@po-ui/ng-components';
import { BreadcrumbControlService, DisclaimerUtil, FieldValidationUtil, TotvsResponse } from 'dts-backoffice-util';
import { DemobilizationReasonService } from '../../../shared/services/demobilization-reason.service';
import { CurrencyService } from '../../../shared/services/currency.service';
import { IDemobilizationReason } from '../../../shared/model/demobilization-reason.model';
import { ICurrency } from '../../../shared/model/currency.model';
import { ITransferParams, TransferParams } from '../../../shared/model/transfer-params.model';
import { AssetTransferService } from '../../../shared/services/asset-transfer.service';
import { IAssetTransferParams } from '../../../shared/model/asset-transfer-params.model';
import { ParamMonitorService } from '../../../shared/services/param-monitor.service';
import { VersionProgramService } from '../../../shared/services/version-program.service';
import { IParamMonitor } from '../../../shared/model/param-monitor.model';
import { IVersionProgram } from '../../../shared/model/version-program.model';
import { RpwService } from '../../../shared/services/rpw.service';
import { CostCenterPlanService } from '../../../shared/services/cost-center-plan.service';
import { CostCenterService } from '../../../shared/services/cost-center.service';
import { BranchService } from '../../../shared/services/branch.service';
import { LocationService } from '../../../shared/services/location.service';


@Component({
  selector: 'app-asset-integration-monitor-transfer',
  templateUrl: './asset-integration-monitor-transfer.component.html'
})
export class AssetIntegrationMonitorTransferComponent implements OnInit, OnDestroy {

  literals: any = {};
  pageActions: Array<PoPageAction>;
  pageBreadcrumb: PoBreadcrumb;
  fieldValidationUtil: FieldValidationUtil;

  monitorSubscription$: Subscription;

  assetColumns: Array<PoTableColumn>;

  transfer = new TransferParams();
  transferAux = new TransferParams();
  radioGroupOptions: Array<PoRadioGroupOption>;

  filterParamsCC = { costCenterPlanCode: '', currentCompany: true };
  filterParamsLocation = { branch: ''};
  disableCostCenter = true;

  zoomBusinessUnit: Array<PoLookupColumn>;
  zoomLocation: Array<PoLookupColumn>;
  zoomBranch: Array<PoLookupColumn>;
  zoomCostCenterPlan: Array<PoLookupColumn>;
  zoomCostCenter: Array<PoLookupColumn>;
  demobReasonOptions: Array<PoSelectOption>;
  currencyOptions: Array<PoSelectOption>;

  disclaimers: Array<PoDisclaimer> = [];
  disclaimerUtil: DisclaimerUtil;

  tableActions: Array<PoPageAction>;
  tableTitle: string;
  disableCurrency = true;
  disableInvoiceValue = true;

  jsonObject: any = {};
  rpwServer: string;
  userRpw: string;
  programVersion: string;
  programName: string;
  procedName: string;


  constructor(
    private activatedRoute: ActivatedRoute,
    private breadcrumbControlService: BreadcrumbControlService,
    private poI18nPipe: PoI18nPipe,
    private thfI18nService: PoI18nService,
    private thfNotification: PoNotificationService,
    private router: Router,
    private poNotification: PoNotificationService,
    private currencyService: CurrencyService,
    private demobReasonService: DemobilizationReasonService,
    private assetTransferService: AssetTransferService,
    private paramMonitorService: ParamMonitorService,
    private versionProgramService: VersionProgramService,
    private rpwService: RpwService,
    public costCenterPlanService: CostCenterPlanService,
    public locationService: LocationService,
    public costCenterService: CostCenterService,
    public branchService: BranchService

  ) { }



  ngOnInit(): void {

    forkJoin([
      this.thfI18nService.getLiterals(),
      this.thfI18nService.getLiterals({ context: 'assetIntegrationMonitorTransfer' })
    ]).subscribe(literals => {
      literals.map(item => Object.assign(this.literals, item));
      this.disclaimerUtil = new DisclaimerUtil(this.poNotification, this.poI18nPipe, this.literals);
      this.fieldValidationUtil = new FieldValidationUtil(this.thfNotification, this.poI18nPipe, this.literals);
      this.setupComponents();

    });
  }

  private return(): void {
    this.router.navigate([this.breadcrumbControlService.getPrevRouter()]);
  }

  public onChangePlan(): void {

    this.filterParamsCC.costCenterPlanCode = this.transfer.requestPlanCostCenter;
    this.disableCostCenter = false;

  }

  /* Valida os campos dos parâmetros */
  private onValidFields(): boolean {
    let isOk = true;

    if (this.transfer.assetTransferParams.length === 0) {
      this.poNotification.error(this.literals['emptyAssetSelect']);
      isOk = false;
    }

    if (!this.fieldValidationUtil.vldFieldDate('transactionDate', this.transfer.transactionDate)) { isOk = false; }

    if (this.transfer.transferType === 1) {
      if (!this.fieldValidationUtil.vldFieldCharacter('costCenterPlan', this.transfer.requestPlanCostCenter)) { isOk = false; }
      if (!this.fieldValidationUtil.vldFieldCharacter('costCenter', this.transfer.requestCostCenter)) { isOk = false; }
    }
    if (this.transfer.transferType === 2) {
      if (this.transfer.requestBranch === '' && this.transfer.$requestBusinessUnit === '') {
        this.poNotification.error(this.literals['validBranchAndBusinessUnit']);
        isOk = false;
      }
      if (!this.disableCurrency) {
        if (!this.fieldValidationUtil.vldFieldCharacter('economicIndicator', this.transfer.economicIndicator)) { isOk = false; }
      }
      if (!this.fieldValidationUtil.vldFieldCharacter('demobReason', this.transfer.demobReason)) { isOk = false; }
    }


    return isOk;
  }

  private executeTransfer(): void {
    this.monitorSubscription$ = this.assetTransferService
      .executeTransfer(this.transferAux, this.transfer.transferType)
      .subscribe(() => {
        this.thfNotification.success(this.literals['rpwTransferSuccess']);
        this.return();
      }, (error: any) => {
        this.thfNotification.error(this.literals['rpwTransferError']);
      });
  }

  private getRpwName(): void {

    this.monitorSubscription$ = this.paramMonitorService
      .getById(' ', ' ').subscribe((resp: IParamMonitor) => {
        if (resp) {
          this.rpwServer = resp.serverCode;
          this.userRpw = resp.userCode;

          this.transferAux = Object.assign({}, this.transfer);

          this.monitorSubscription$ = this.assetTransferService
          .searchPreviousRequests(this.transferAux)
          .subscribe(() => {
            this.schedule();
          }, (error: any) => {
            this.thfNotification.error(this.literals['rpwTransferError']);
          });

          /*
          this.transferAux.assetTransferParams = [];

          this.transfer.assetTransferParams.forEach(assetTransferParamItem => {
            this.transferAux.assetTransferParams[0] = assetTransferParamItem;
            this.schedule();
          });
          */

        }
      }, (erro: any) => {
        this.poNotification.error(this.literals['errorFindRpwServer']);
      });
  }
  private getProgramName(): void {

    if (this.transfer.transferType === 1) {
      this.programName = 'rnl_bem_pat_transf_int';
      this.procedName = 'tar_transferencia_interna';
    } else {
      this.programName = 'rnl_bem_pat_transf_ext';
      this.procedName = 'tar_transferencia_externa';
    }

    this.monitorSubscription$ = this.versionProgramService
      .get(this.programName).subscribe((resp: IVersionProgram) => {
        if (resp) {
          this.programVersion = resp.versionCode;
          this.getRpwName();
        }
      }, (erro: any) => {
        this.poNotification.error(this.literals['errorFindProgramVersion']);
      });
  }

  public schedule() {

    this.jsonObject = {};
    this.jsonObject.status = 'active';
    this.jsonObject.processID = this.programName;
    this.jsonObject.recurrent = false;
    this.jsonObject.user = this.userRpw;
    this.jsonObject.executionParameter = {};

    this.jsonObject.executionParameter.parametros = [];
    this.jsonObject.executionParameter.parametros[0] = { 'chave': 'rpwServer', 'valor': this.rpwServer };
    this.jsonObject.executionParameter.parametros[1] = { 'chave': 'RPW_PROGRAM', 'valor': this.procedName };
    this.jsonObject.executionParameter.parametros[2] = { 'chave': 'RPW_PRG_EMS5', 'valor': 'yes' };
    this.jsonObject.executionParameter.parametros[3] = { 'chave': 'RPW_PRG_ESTILO', 'valor': '30' },
    this.jsonObject.executionParameter.parametros[4] = { 'chave': 'RPW_PRG_VERS', 'valor': this.programVersion };
    this.jsonObject.executionParameter.parametros[5] = {};
    this.jsonObject.executionParameter.parametros[5].parametros_negocio = [{ 'chave': '', 'valor': '' }];


    this.rpwService.rpwExecute(this.jsonObject, true).subscribe(resp => {

      if (resp.jobScheduleID === '') {
        this.poNotification.error(this.literals['errorCreateRpwID']);
      } else {
        this.transferAux.jobScheduleID = resp.jobScheduleID;
        this.executeTransfer();
      }
    });
  }


  private transferMovement(): void {

    if (this.onValidFields()) {
      this.getProgramName();
    }
  }

  private addDisclaimer(disclaimerListItem: Array<PoDisclaimer>): void {
    if (!disclaimerListItem) { return; }

    disclaimerListItem.forEach(disclaimerItem => {
      this.disclaimers.push(disclaimerItem);
    });
  }


  private loadRequestDetails(): void {
    const id = JSON.parse(sessionStorage.getItem('Movement_request'));
    if (id.length === 1) {
      this.tableTitle = this.literals['fixedAsset'];
    } else {
      this.tableTitle = this.literals['fixedAssets'];
    }

    this.transfer.assetTransferParams = [];

    id.forEach(request => {

      this.disclaimers = [];
      this.addDisclaimer([
        this.disclaimerUtil.makeDisclaimer('idRequest', request)
      ]);

      this.monitorSubscription$ = this.assetTransferService
        .query(this.disclaimers, 0, 9999, true)
        .subscribe((response: TotvsResponse<IAssetTransferParams>) => {
          response.items.forEach(param => {
            this.transfer.transactionDate = param.transactionDate;
            this.transfer.requestPlanCostCenter = param.planCostCenter;
            this.transfer.requestCostCenter = param.costCenter;
            this.transfer.requestBranch = param.branch;
            this.transfer.assetTransferParams.push(param);

            if (param.costCenter !== '' && param.costCenter !== null) {
              this.transfer.transferType = 1;
            } else {
              this.transfer.transferType = 2;
            }
          });
        });
    });

  }

  public onChangeDemobReason(): void {
    this.monitorSubscription$ = this.demobReasonService
      .getById(this.transfer.demobReason)
      .subscribe((response: IDemobilizationReason) => {
        if (response.genReceipt) {
          this.disableCurrency = false;
          this.disableInvoiceValue = false;
        } else {
          this.disableCurrency = true;
          this.disableInvoiceValue = true;
        }
      });
  }

  private loadServices(): void {
    this.currencyOptions = [];
    this.demobReasonOptions = [];


    this.monitorSubscription$ = this.currencyService
      .query([], 0, 9999, true)
      .subscribe((response: TotvsResponse<ICurrency>) => {
        this.currencyOptions.length = 0;
        response.items.forEach(currency => {
          this.currencyOptions.push({
            label: `${currency.code} - ${currency.description}`,
            value: currency.code
          });
        });
      }, (err: any) => {
      });

    this.monitorSubscription$ = this.demobReasonService
      .query([], 0, 9999, true)
      .subscribe((response: TotvsResponse<IDemobilizationReason>) => {
        this.demobReasonOptions.length = 0;
        response.items.forEach(reason => {
          this.demobReasonOptions.push({
            label: `${reason.reasonCode} - ${reason.descReason}`,
            value: reason.reasonCode
          });
        });
      }, (err: any) => {
      });


  }


  private removeAsset(asset: IAssetTransferParams): void {
    const idx = this.transfer.assetTransferParams.indexOf(asset);
    this.transfer.assetTransferParams.splice(idx, 1);
  }

  fieldCCFormat(value) {
    return `${value.costCenterCode} - ${value.costCenterName}`;
  }

  fieldBUFormat(value) {
    return `${value.businessUnitCode} - ${value.businessUnitName}`;
  }

  fieldLocationFormat(value) {
    return `${value.locationCode} - ${value.locationName}`;
  }

  fieldBranchFormat(value) {
    return `${value.branchCode} - ${value.branchShortName}`;
  }

  fieldCCPlanFormat(value) {
    return `${value.costCenterPlanCode} - ${value.costCenterPlanName}`;
  }

  private setupComponents(): void {

    this.breadcrumbControlService.addBreadcrumb(this.literals['requestMovement'], this.activatedRoute);
    this.pageBreadcrumb = this.breadcrumbControlService.getBreadcrumb();

    this.pageActions = [
      { label: this.literals['execute'], action: this.transferMovement.bind(this, this.transfer), type: 'default' },
      { label: this.literals['return'], action: this.return.bind(this), type: 'default' }
    ];


    this.radioGroupOptions = [
      { label: this.literals['internal'], value: 1 },
      { label: this.literals['external'], value: 2 }
    ];

    this.assetColumns = [
      { label: this.literals['assetAccount'], property: 'assetCode', type: 'string' },
      { label: this.literals['fixedAsset'], property: 'desAssetSeqNumber', type: 'string' },
      { label: this.literals['descFixedAsset'], property: 'descFixedAsset', type: 'string' },
      { label: this.literals['branch'], property: 'requestBranch', type: 'string' },
      { label: this.literals['costCenter'], property: 'requestCostCenter', type: 'string' },
      { label: this.literals['businessUnit'], property: 'requestBusinessUnit', type: 'string' },

    ];

    this.zoomCostCenter = [
      { property: 'costCenterPlanCode', label: this.literals['costCenterPlan'], type: 'string', width: '25%' },
      { property: 'costCenterCode', label: this.literals['costCenter'], type: 'string', width: '40%' },
      { property: 'costCenterName', label: this.literals['costCenterName'], type: 'string', width: '50%' }
    ];

    this.zoomBusinessUnit = [
      { property: 'businessUnitCode', label: this.literals['businessUnit'], type: 'string', width: '30%' },
      { property: 'businessUnitName', label: this.literals['businessUnitName'], type: 'string', width: '50%' }
    ];

    this.zoomLocation = [
      { property: 'branch', label: this.literals['branch'], type: 'string', width: '20%' },
      { property: 'locationCode', label: this.literals['location'], type: 'string', width: '30%' },
      { property: 'locationName', label: this.literals['locationName'], type: 'string', width: '50%' }
    ];

    this.zoomBranch = [
      { property: 'branchCode', label: this.literals['branch'], type: 'string', width: '20%' },
      { property: 'branchShortName', label: this.literals['branchName'], type: 'string', width: '50%' }
    ];

    this.zoomCostCenterPlan = [
      { property: 'costCenterPlanCode', label: this.literals['costCenterPlan'], type: 'string', width: '30%' },
      { property: 'costCenterPlanName', label: this.literals['costCenterPlanName'], type: 'string', width: '50%' }
    ];

    this.tableActions = [
      { label: this.literals['remove'], action: this.removeAsset.bind(this), icon: 'po-icon po-icon-delete' }
    ];


    this.loadServices();

    this.loadRequestDetails();

  }

  ngOnDestroy(): void {
    if (this.monitorSubscription$) {
      this.monitorSubscription$.unsubscribe();
    }
  }
}
