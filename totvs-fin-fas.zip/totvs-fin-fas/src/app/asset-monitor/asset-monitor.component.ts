import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { CompanyService } from '../shared/services/company.service';
import { PoPageAction, PoMenuItem, PoI18nService } from '@po-ui/ng-components';
import { forkJoin } from 'rxjs';

@Component({
    selector: 'app-asset-monitor',
    templateUrl: './asset-monitor.component.html',
    styleUrls: ['./asset-monitor.component.css']
})
export class AssetMonitorComponent implements OnInit {

    public formulario: FormGroup;
    menuItems: Array<PoMenuItem>;
    literals: any = {};

    public pageActions: Array<PoPageAction>;

    constructor(
        public companyService: CompanyService,
        private poI18nService: PoI18nService
    ) { }

    ngOnInit(): void {
        forkJoin([
            this.poI18nService.getLiterals(),
            this.poI18nService.getLiterals({ context: 'assetMonitor' })
        ]).subscribe(literals => {
            literals.map(item => Object.assign(this.literals, item));
            this.setupComponents();
        });
    }

    private setupComponents(): void {

      this.menuItems = [
        {
          label: this.literals['integrationMonitor'],
          icon: 'po-icon-home',
          shortLabel: this.literals['monitor'],
          link: '/assetMonitor/assetIntegrationMonitor'
        },
        {
          label: this.literals['inventoryActive'],
          icon: 'po-icon-handshake',
          shortLabel: this.literals['inventory'],
          link: '/assetMonitor/assetInventoryActive'
        }
      ];
    }
}
