import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AssetIntegrationMonitorComponent  } from './asset-integration-monitor/asset-integration-monitor.component';
import { AssetInventoryActiveComponent } from './asset-inventory-active/asset-inventory-active.component';
import { AppComponent } from '../app.component';
import { AssetMonitorComponent } from './asset-monitor.component';


const routes: Routes = [
    {
        path: '',
        component: AssetMonitorComponent,
        children: [
            {
                path: 'assetIntegrationMonitor',
                component: AssetIntegrationMonitorComponent
            },
            {
                path: 'assetInventoryActive',
                component: AssetInventoryActiveComponent
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})

export class AssetMonitorRoutingModule { }
