import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { PoModule } from '@po-ui/ng-components';
import { PoI18nPipe } from '@po-ui/ng-components';
import { DtsBackofficeUtilsModule } from 'dts-backoffice-util';
import { AssetMonitorRoutingModule } from './asset-monitor-routing.module';
import { AssetMonitorComponent } from './asset-monitor.component';
import { AssetIntegrationMonitorService } from '../shared/services/asset-integration-monitor.service';
import { AssetInventoryActiveService } from '../shared/services/asset-inventory-active.service';

import { AssetIntegrationMonitorComponent } from './asset-integration-monitor/asset-integration-monitor.component';
import { AssetInventoryActiveComponent } from './asset-inventory-active/asset-inventory-active.component';
import { CompanyService } from '../shared/services/company.service';
import { AssetIntegrationMonitorDetailService } from '../shared/services/asset-integration-monitor-detail.service';
import { CurrencyService } from '../shared/services/currency.service';
import { AccountingScenarioService } from '../shared/services/accounting-scenario.service';
import { DemobilizationReasonService } from '../shared/services/demobilization-reason.service';
import { AssetRetirementService } from '../shared/services/asset-retirement.service';
import { PersonService } from '../shared/services/person.service';
import { DeliveryAddressService } from '../shared/services/delivery-address.service';
import { CostCenterPlanService } from '../shared/services/cost-center-plan.service';
import { LocationService } from '../shared/services/location.service';
import { AssetTransferService } from '../shared/services/asset-transfer.service';
import { RpwService } from '../shared/services/rpw.service';
import { ParamMonitorService } from '../shared/services/param-monitor.service';
import { VersionProgramService } from '../shared/services/version-program.service';
import { CostCenterService } from '../shared/services/cost-center.service';
import { KeepFiltersService } from '../shared/services/keep-filters.service';
import { BranchService } from '../shared/services/branch.service';

@NgModule({
    imports: [
        CommonModule,
        PoModule,
        FormsModule,
        ReactiveFormsModule,
        DtsBackofficeUtilsModule.forRoot(),
        HttpClientModule,
        AssetMonitorRoutingModule
    ],
    declarations: [
        AssetMonitorComponent,
        AssetIntegrationMonitorComponent,
        AssetInventoryActiveComponent,
    ],
    exports: [
        AssetMonitorComponent,
        AssetIntegrationMonitorComponent,
        AssetInventoryActiveComponent,
    ],
    providers: [
        PoI18nPipe,
        CompanyService,
        AssetIntegrationMonitorService,
        AssetIntegrationMonitorDetailService,
        CurrencyService,
        AccountingScenarioService,
        DemobilizationReasonService,
        AssetRetirementService,
        PersonService,
        DeliveryAddressService,
        CostCenterPlanService,
        LocationService,
        AssetTransferService,
        RpwService,
        ParamMonitorService,
        VersionProgramService,
        CostCenterService,
        KeepFiltersService,
        BranchService,
        AssetIntegrationMonitorService,
    ]
})
export class AssetMonitorModule { }

