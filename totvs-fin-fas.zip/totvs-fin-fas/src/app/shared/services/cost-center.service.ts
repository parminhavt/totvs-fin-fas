import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { ICostCenter } from '../model/cost-center.model';
import { PoLookupFilter, PoLookupFilteredItemsParams } from '@po-ui/ng-components';


@Injectable()
export class CostCenterService implements PoLookupFilter {

  private headers = { headers: { 'X-PO-Screen-Lock': 'true' } };
  private apiUrl = '/dts/datasul-rest/resources/prg/fin/v1/costCenter';

  constructor(private http: HttpClient) { }

  getFilteredItems(filteredParams: PoLookupFilteredItemsParams): Observable<any> {
    const { filterParams, advancedFilters, ...restFilteredItemsParams } = filteredParams;
    const params = { ...restFilteredItemsParams, ...filterParams, ...advancedFilters, costCenterPlanCode: filterParams.costCenterPlanCode };

    return this.http.get(this.apiUrl, { params });
  }

  getObjectByValue(costCenterCode: string, filterParams?: any): Observable<any> {
    costCenterCode = btoa(costCenterCode);

    if (filterParams && filterParams.hideLoading) {
        return this.http.get<ICostCenter>(
            `${this.apiUrl}/${costCenterCode}?costCenterPlanCode=${filterParams.costCenterPlanCode}`, this.headers
        );
    } else {
        return this.http.get<ICostCenter>(`${this.apiUrl}/${costCenterCode}?costCenterPlanCode=${filterParams.costCenterPlanCode}`);
    }
}

}
