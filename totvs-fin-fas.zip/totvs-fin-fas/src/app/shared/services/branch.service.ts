import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { IBranch } from '../model/branch.model';
import { PoLookupFilter, PoLookupFilteredItemsParams } from '@po-ui/ng-components';


@Injectable()
export class BranchService implements PoLookupFilter {

  private headers = { headers: { 'X-PO-Screen-Lock': 'true' } };
  private apiUrl = '/dts/datasul-rest/resources/prg/fin/v1/branch';

  constructor(private http: HttpClient) { }

  getFilteredItems(filteredParams: PoLookupFilteredItemsParams): Observable<any> {
    const { filterParams, advancedFilters, ...restFilteredItemsParams } = filteredParams;
    const params = { ...restFilteredItemsParams, ...filterParams, ...advancedFilters };

    return this.http.get(this.apiUrl, { params });
  }

  getObjectByValue(branchCode: string): Observable<any> {
    return this.http.get<IBranch>(`${this.apiUrl}/${branchCode}`);

  }

}
