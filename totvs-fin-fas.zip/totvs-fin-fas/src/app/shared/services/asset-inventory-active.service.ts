import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { PoDisclaimer } from '@po-ui/ng-components';
import { TotvsResponse } from 'dts-backoffice-util';
import { IAssetInventoryActive } from '../model/asset-inventory-active.model';

@Injectable()
export class AssetInventoryActiveService {

    private apiUrl = '/dts/datasul-rest/resources/prg/fin/v1/requests';

    constructor(private http: HttpClient) { }

    query(filters: PoDisclaimer[], page = 1, pageSize = 20): Observable<TotvsResponse<IAssetInventoryActive>> {

        let url = `${this.apiUrl}?pageSize=${pageSize}&page=${page}`;
        if (filters && filters.length > 0) {
            const urlParams = new Array();
            filters.forEach(filter => {
                urlParams.push(`${filter.property}=${filter.value}`);
            });
            url = `${url}&${urlParams.join('&')}`;
        }
        return this.http.get<TotvsResponse<IAssetInventoryActive>>(url);
    }

    getById(id: string): Observable<IAssetInventoryActive> {
        return this.http.get<IAssetInventoryActive>(`${this.apiUrl}/${id}`);
    }


    getMetadata(): Observable<any> {
        return this.http.get<any>(`${this.apiUrl}/metadata/`);
    }

    getMetadataList(): Observable<any> {
        return this.getMetadata();
    }
}
