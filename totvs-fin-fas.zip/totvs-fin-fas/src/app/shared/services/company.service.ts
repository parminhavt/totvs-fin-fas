import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { ICompany } from '../model/company.model';
import { PoDisclaimer } from '@po-ui/ng-components';
import { TotvsResponse } from 'dts-backoffice-util';


@Injectable()
export class CompanyService {

    private headers = { headers: { 'X-PO-Screen-Lock': 'true' } };
    private apiUrl = '/dts/datasul-rest/resources/prg/fin/v1/company';

    constructor(private http: HttpClient) { }

    query(filters: PoDisclaimer[], page = 1, pageSize = 20, screenLoading = false): Observable<TotvsResponse<ICompany>> {
        let url = '';
        const urlParams = new Array<string>();

        urlParams.push(`pageSize=${pageSize}`);
        urlParams.push(`page=${page}`);

        if (filters && filters.length > 0) {
            filters.forEach(filter => {
                urlParams.push(`${filter.property}=${filter.value}`);
            });
        }

        url = `${this.apiUrl}?${urlParams.join('&')}`;

        if (screenLoading) {
            return this.http.get<TotvsResponse<ICompany>>(url, this.headers);
        } else {
            return this.http.get<TotvsResponse<ICompany>>(url);
        }
    }

    getFilteredData(filter: string, page: number, pageSize: number, filterParams?: any): Observable<ICompany> {

        const header = {params: {page: page.toString(), pageSize: pageSize.toString()}};

        if (filter && filter.length > 0) {
            header.params['companyCode'] = filter;
        }

        if (filterParams && filterParams.loading) {
            header['headers'] = this.headers.headers;
        }

        return this.http.get<ICompany>(this.apiUrl, header);
    }

    getObjectByValue(companyCode: string, filterParams?: any): Observable<ICompany> {
        companyCode = btoa(companyCode);

        if (filterParams && filterParams.loading) {
            return this.http.get<ICompany>(`${this.apiUrl}/${companyCode}`, this.headers);
        } else {
            return this.http.get<ICompany>(`${this.apiUrl}/${companyCode}`);
        }
    }

    getCurrentCompany(screenLoading = false): Observable<ICompany> {
        if (screenLoading) {
            return this.http.get<ICompany>(this.apiUrl + '/currentCompany', this.headers);
        } else {
            return this.http.get<ICompany>(this.apiUrl + '/currentCompany');
        }

    }
}
