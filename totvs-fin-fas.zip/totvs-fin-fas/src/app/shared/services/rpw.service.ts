import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

@Injectable()
export class RpwService {

    private headers = { headers: { 'X-PO-Screen-Lock': 'true' } };

    readonly systemUrl = '/dts/datasul-rest/resources/prg';
    urlJobScheduler = `${this.systemUrl}/framework/v1/jobScheduler`;
    urlServer = `${this.systemUrl}/btb/v1/servidoresExecucao`;

    constructor(private http: HttpClient) { }

    rpwExecute(parameters: object, screenLoading = false): Observable<any> {
        const params = JSON.parse(JSON.stringify(parameters).replace(/\\\\/g, '*|'));

        if (screenLoading) {
            return this.http.post(
                `${this.urlJobScheduler}`, params, this.headers
            );
        } else {
            return this.http.post(
                `${this.urlJobScheduler}`, params
            );
        }
    }

    delete(jobScheduleID: string): Observable<any> {

        return this.http.delete(
            `${this.urlJobScheduler}/${jobScheduleID}`
        );
    }

    getFilteredItems(filter: any, filterParams?: any): Observable<any> {
        const header = { params: { page: filter.page.toString(), pageSize: filter.pageSize.toString() } };

        if (filter && filter.filter !== '') {
            header.params['quickSearch'] = filter.filter;
        }

        if (filterParams && filterParams.hideLoading) {
            header.params['filterOUnit'] = filterParams.filterOUnit;
        }

        return this.http.get(`${this.urlServer}`, header);
    }

    getObjectByValue(id: string, filterParams: any): Observable<any> {
        if (filterParams && filterParams.hideLoading) {
            return this.http.get<any>(`${this.urlServer}/${id}`, this.headers);
        } else {
            return this.http.get<any>(`${this.urlServer}/${id}`);
        }
    }

}
