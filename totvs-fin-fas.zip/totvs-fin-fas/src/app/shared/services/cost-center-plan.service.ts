import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { ICostCenterPlan } from '../model/cost-center-plan.model';
import { PoLookupFilter, PoLookupFilteredItemsParams } from '@po-ui/ng-components';


@Injectable()
export class CostCenterPlanService implements PoLookupFilter {

  private headers = { headers: { 'X-PO-Screen-Lock': 'true' } };
  private apiUrl = '/dts/datasul-rest/resources/prg/fin/v1/costCenterPlan';

  constructor(private http: HttpClient) { }

  getFilteredItems(filteredParams: PoLookupFilteredItemsParams): Observable<any> {
    const { filterParams, advancedFilters, ...restFilteredItemsParams } = filteredParams;
    const params = { ...restFilteredItemsParams, ...filterParams, ...advancedFilters };

    return this.http.get(this.apiUrl, { params });
  }

  getObjectByValue(costCenterPlanCode: string): Observable<any> {
    costCenterPlanCode = btoa(costCenterPlanCode);

    return this.http.get<ICostCenterPlan>(`${this.apiUrl}/${costCenterPlanCode}`);

  }

}
