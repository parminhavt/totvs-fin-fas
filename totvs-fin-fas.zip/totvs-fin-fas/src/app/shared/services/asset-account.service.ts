import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { TotvsResponse } from 'dts-backoffice-util';
import { PoDisclaimer } from '@po-ui/ng-components';
import { IAssetAccount } from '../model/asset-account.model';


@Injectable()
export class AssetAccountService {

    private headers = { headers: { 'X-PO-Screen-Lock': 'true' } };
    private apiUrl = '/dts/datasul-rest/resources/prg/fin/v1/assetAccount';

    constructor(private http: HttpClient) { }

    query(filters: PoDisclaimer[], page = 1, pageSize = 20, screenLoading = false): Observable<TotvsResponse<IAssetAccount>> {
        let url = '';
        const urlParams = new Array<string>();

        urlParams.push(`pageSize=${pageSize}`);
        urlParams.push(`page=${page}`);

        if (filters && filters.length > 0) {
            filters.forEach(filter => {
                urlParams.push(`${filter.property}=${filter.value}`);
            });
        }

        url = `${this.apiUrl}?${urlParams.join('&')}`;

        if (screenLoading) {
            return this.http.get<TotvsResponse<IAssetAccount>>(url, this.headers);
        } else {
            return this.http.get<TotvsResponse<IAssetAccount>>(url);
        }
    }

    getById(assetCode: string, screenLoading = false): Observable<IAssetAccount> {
      assetCode = btoa(assetCode);
      if (screenLoading) {
          return this.http.get<IAssetAccount>(`${this.apiUrl}/${assetCode}`, this.headers);
      } else {
          return this.http.get<IAssetAccount>(`${this.apiUrl}/${assetCode}`);
      }

    }


}
