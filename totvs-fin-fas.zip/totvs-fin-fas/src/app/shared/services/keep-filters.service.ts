import { Injectable } from '@angular/core';
import { PoPageDynamicTableComponent } from '@po-ui/ng-templates';
@Injectable({
    providedIn: 'root'
})
export class KeepFiltersService {
    private initialFieldsRequest: Array<any>;
    private initialFieldsInventory: Array<any>;
    private hasSearch = false;
    private document: string;

    constructor() {
    }

    start() {
        switch (this.document) {
            case 'request': {
                this.initialFieldsRequest = [];
                break;
            }
            case 'inventory': {
                this.initialFieldsInventory = [];
                break;
            }

        }
    }

    setDocument(document: string) {
        this.document = document;
    }

    getDocument() {
        return this.document;
    }

    addInitialValue(propertyStr: string, initValueObj: any) {

        if (!initValueObj) {
            this.start();
        }
        this.hasSearch = propertyStr === 'search';
        switch (this.document) {
            case 'request': {
                this.initialFieldsRequest.push({ property: propertyStr, initValue: initValueObj });
                break;
            }
            case 'inventory': {
                this.initialFieldsInventory.push({ property: propertyStr, initValue: initValueObj });
                break;
            }
        }
    }

    getInitialFields(): Array<any> {
        switch (this.document) {
            case 'request': {
                return this.initialFieldsRequest;
            }
            case 'inventory': {
                return this.initialFieldsInventory;
            }
        }
    }


    savePageDynamicTableFilters(pageDynamicTable: PoPageDynamicTableComponent) {
        if (pageDynamicTable) {
            pageDynamicTable.filters.forEach(field => {
                if (field.initValue) {
                    this.addInitialValue(field.property, field.initValue);
                }
            });
            if (!this.hasSearch && pageDynamicTable['params']['search']) {
                 this.addInitialValue('search', pageDynamicTable['params']['search']);
             } else {
                if (this.hasSearch && pageDynamicTable['params']['search'] !== undefined) {
                    this.addInitialValue('search', pageDynamicTable['params']['search']);
                }
            }
        }
    }

    updateMetadataInitials(document: string, metadata: any) {
        this.setDocument(document);
        if (metadata && this.getInitialFields()) {
            metadata.fields.forEach(field => {
                if (field.initValue) {
                    field.initValue = '';
                }
                this.getInitialFields().forEach(fieldUser => {
                    if (field.property === fieldUser.property) {
                        field.initValue = fieldUser.initValue;
                    }
                });
            });
        }
    }
}
