import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { TotvsResponse } from 'dts-backoffice-util';
import { PoDisclaimer, PoLookupFilteredItemsParams } from '@po-ui/ng-components';
import { ILocation } from '../model/location.model';


@Injectable()
export class LocationService {

    private headers = { headers: { 'X-PO-Screen-Lock': 'true' } };
    private apiUrl = '/dts/datasul-rest/resources/prg/fin/v1/location';

    constructor(private http: HttpClient) { }

    query(filters: PoDisclaimer[], page = 1, pageSize = 20, screenLoading = false): Observable<TotvsResponse<ILocation>> {
        let url = '';
        const urlParams = new Array<string>();

        urlParams.push(`pageSize=${pageSize}`);
        urlParams.push(`page=${page}`);

        if (filters && filters.length > 0) {
            filters.forEach(filter => {
                urlParams.push(`${filter.property}=${filter.value}`);
            });
        }

        url = `${this.apiUrl}?${urlParams.join('&')}`;

        if (screenLoading) {
            return this.http.get<TotvsResponse<ILocation>>(url, this.headers);
        } else {
            return this.http.get<TotvsResponse<ILocation>>(url);
        }
    }

    getById(id: string, screenLoading = false): Observable<ILocation> {
      if (screenLoading) {
          return this.http.get<ILocation>(`${this.apiUrl}/${id}`, this.headers);
      } else {
          return this.http.get<ILocation>(`${this.apiUrl}/${id}`);
      }

    }

    getObjectByValue(locationCode: string, filterParams?: any): Observable<any> {
      if (filterParams && filterParams.hideLoading) {
          return this.http.get<ILocation>(
              `${this.apiUrl}/${locationCode}?branchCode=${filterParams.branch}`, this.headers
          );
      } else {
          return this.http.get<ILocation>(`${this.apiUrl}/${locationCode}?branchCode=${filterParams.branch}`);
      }
  }

    getFilteredItems(filteredParams: PoLookupFilteredItemsParams): Observable<any> {
      const { filterParams, advancedFilters, ...restFilteredItemsParams } = filteredParams;
      const params = { ...restFilteredItemsParams, ...filterParams, ...advancedFilters, branch : filterParams.branch };

      return this.http.get(this.apiUrl, { params });
    }

}
