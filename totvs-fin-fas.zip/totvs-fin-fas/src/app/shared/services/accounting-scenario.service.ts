import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { PoDisclaimer } from '@po-ui/ng-components';
import { TotvsResponse } from 'dts-backoffice-util';
import { IAccountingScenario } from '../model/accounting-scenario.model';

import { Observable } from 'rxjs';

import { PoLookupFilter, PoLookupResponseApi } from '@po-ui/ng-components';

@Injectable()
export class AccountingScenarioService implements PoLookupFilter {

    private headers = { headers: { 'X-PO-Screen-Lock': 'true' } };
    private apiUrl = '/dts/datasul-rest/resources/prg/fin/v1/accountingScenario';

    constructor(private http: HttpClient) { }

    getFilteredData(filter: any, page: number, pageSize?: number): Observable<PoLookupResponseApi> {
        const header = { params: { page: page.toString(), pageSize: pageSize.toString()} };

        // Adiciona o filtro pesquisado no zoom
        if (filter && filter.length > 0) {
            header.params['accountingScenarioCode'] = filter;
        }

        return this.http.get<any>(this.apiUrl, header);
    }

    getObjectByValue(accountingScenarioCode: string, filterParams: any): Observable<any> {
        accountingScenarioCode = btoa(accountingScenarioCode);

        if (filterParams && filterParams.hideLoading) {
            return this.http.get<any>(`${this.apiUrl}/${accountingScenarioCode}`, this.headers);
        } else {
            return this.http.get<any>(`${this.apiUrl}/${accountingScenarioCode}`);
        }
    }

    query(filters: PoDisclaimer[], page = 1, pageSize = 20, screenLoading = false): Observable<TotvsResponse<IAccountingScenario>> {

        let url = `${this.apiUrl}?pageSize=${pageSize}&page=${page}`;
        if (filters && filters.length > 0) {

            const urlParams = new Array<string>();

            filters.forEach(filter => {
                urlParams.push(`${filter.property}=${filter.value}`);
            });

            url = `${url}&${urlParams.join('&')}`;
        }

        if (screenLoading) {
            return this.http.get<TotvsResponse<IAccountingScenario>>(url, this.headers);
        } else {
            return this.http.get<TotvsResponse<IAccountingScenario>>(url);
        }

    }



}
