import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { TotvsResponse } from 'dts-backoffice-util';
import { PoDisclaimer } from '@po-ui/ng-components';
import { IAssetAccount } from '../model/asset-account.model';
import { IAssetIntegrationMonitorMovements } from '../model/asset-integration-monitor-movements.model';
import { IAssetIntegrationMonitorDetail } from '../model/asset-integration-monitor-detail.model';


@Injectable()
export class AssetIntegrationMonitorDetailService {

  private headers = { headers: { 'X-PO-Screen-Lock': 'true' } };
  private apiUrl = '/dts/datasul-rest/resources/prg/fin/v1/assetIntegrationMonitorDetail';
  private apiCancelRequest = `${this.apiUrl}/cancelRequest`;

  constructor(private http: HttpClient) { }

  private expandables = ['assetMovements'];

  query(filters: PoDisclaimer[], expandables: string[], page = 1, pageSize = 20):
    Observable<TotvsResponse<IAssetIntegrationMonitorDetail>> {
    const url = this.getUrl(this.apiUrl, filters, expandables, page, pageSize);

    return this.http.get<TotvsResponse<IAssetIntegrationMonitorDetail>>(url, this.headers);
  }

  getUrl(urlBase: string, filters: PoDisclaimer[], expandables: string[], page: number, pageSize: number): string {
    const urlParams = new Array<string>();

    urlParams.push(`pageSize=${pageSize}`);
    urlParams.push(`page=${page}`);

    const lstExpandables = this.getExpandables(expandables);
    if (lstExpandables !== '') { urlParams.push(lstExpandables); }

    if (filters && filters.length > 0) {
      filters.map(filter => {
        urlParams.push(`${filter.property}=${filter.value}`);
      });
    }

    return `${urlBase}?${urlParams.join('&')}`;
  }

  getById(id: string, screenLoading = false): Observable<IAssetIntegrationMonitorDetail> {

    if (screenLoading) {
      return this.http.get<IAssetIntegrationMonitorDetail>(`${this.apiUrl}/${id}`, this.headers);
    } else {
      return this.http.get<IAssetIntegrationMonitorDetail>(`${this.apiUrl}/${id}`);
    }
  }

  getExpandables(expandables: string[]): string {
    let lstExpandables = '';

    if (expandables && expandables.length > 0) {
      expandables.map(expandable => {
        if (expandable !== '' && this.expandables.includes(expandable)) {
          if (lstExpandables !== '') { lstExpandables = `${lstExpandables},`; }
          lstExpandables = `${lstExpandables}${expandable}`;
        }
      });
    }

    if (lstExpandables !== '') { lstExpandables = `expand=${lstExpandables}`; }

    return lstExpandables;
  }

  cancelRequest(params: IAssetIntegrationMonitorDetail) {
    const url = `${this.apiCancelRequest}?`;

    return this.http.put<string>(url, params);
}



}
