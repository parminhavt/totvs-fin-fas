import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { IVersionProgram } from '../model/version-program.model';

@Injectable()
export class VersionProgramService {

    // FIXME: Change to the backend service URL
    private headers = { headers: { 'X-PO-Screen-Lock': 'true' } };
    private apiUrl = '/dts/datasul-rest/resources/prg/fin/v1/versionProgram';

    constructor(private http: HttpClient) { }

    /** Busca a versão do programa */
    get(programName: string): Observable<IVersionProgram> {
      return this.http.get<IVersionProgram>(`${this.apiUrl}/${programName}`);
  }

}
