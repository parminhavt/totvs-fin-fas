import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { TotvsResponse } from 'dts-backoffice-util';
import { PoDisclaimer } from '@po-ui/ng-components';
import { IFixedAsset } from '../model/fixed-asset.model';


@Injectable()
export class AssetAccountService {

    private headers = { headers: { 'X-PO-Screen-Lock': 'true' } };
    private apiUrl = '/dts/datasul-rest/resources/prg/fin/v1/fixedAsset';

    constructor(private http: HttpClient) { }

    query(filters: PoDisclaimer[], page = 1, pageSize = 20, screenLoading = false): Observable<TotvsResponse<IFixedAsset>> {
        let url = '';
        const urlParams = new Array<string>();

        urlParams.push(`pageSize=${pageSize}`);
        urlParams.push(`page=${page}`);

        if (filters && filters.length > 0) {
            filters.forEach(filter => {
                urlParams.push(`${filter.property}=${filter.value}`);
            });
        }

        url = `${this.apiUrl}?${urlParams.join('&')}`;

        if (screenLoading) {
            return this.http.get<TotvsResponse<IFixedAsset>>(url, this.headers);
        } else {
            return this.http.get<TotvsResponse<IFixedAsset>>(url);
        }
    }

    getById(assetCode: string, fixedNumber: number, fixedSeqNumber: number, screenLoading = false): Observable<IFixedAsset> {
      const id = assetCode + ';' + fixedNumber.toString() + ';' + fixedSeqNumber.toString();
      if (screenLoading) {
          return this.http.get<IFixedAsset>(`${this.apiUrl}/${id}`, this.headers);
      } else {
          return this.http.get<IFixedAsset>(`${this.apiUrl}/${id}`);
      }

    }


}
