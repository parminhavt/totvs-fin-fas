import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { TotvsResponse } from 'dts-backoffice-util';

import { IPerson } from '../model/person.model';
import { PoDisclaimer, PoLookupFilter, PoLookupFilteredItemsParams } from '@po-ui/ng-components';
import { IContact } from '../model/contact.model';

@Injectable()
export class PersonService  {
  private headers = { headers: { 'X-PO-Screen-Lock': 'true' } };

  private apiUrl = '/dts/datasul-rest/resources/prg/fin/v1/person';
  private apiContact = '/contact';

  // private apiUrl = '/person';

  private expandables = ['contacts'];

  constructor(private http: HttpClient) { }

  query(personType: number, filters: PoDisclaimer[], expandables: string[], page = 1, pageSize = 20):
    Observable<TotvsResponse<IPerson>> {

    if (!filters) { filters = new Array<PoDisclaimer>(); }
    filters.push({ property: 'personType', value: personType });

    const url = this.getUrl(this.apiUrl, filters, expandables, page, pageSize);

    return this.http.get<TotvsResponse<IPerson>>(url, this.headers);
  }

  getById(id: string, expandables: string[]): Observable<IPerson> {
    let lstExpandables = this.getExpandables(expandables);
    if (lstExpandables !== '') { lstExpandables = `&${lstExpandables}`; }

    return this.http.get<IPerson>(`${this.apiUrl}/${id}?${lstExpandables}`, this.headers);
  }

  getObjectByValue(id: string, filterParams: any): Observable<IPerson> {
    let filter = '';
    if (filterParams && filterParams.personType > 0) {
      filter = `?personType=${filterParams.personType}`;
    }

    return this.http.get<IPerson>(`${this.apiUrl}/${id}${filter}`);
  }

  getFilteredData(filter: string, page: number, pageSize: number, filterParams?: any): Observable<any> {
    const header = { params: { page: page.toString(), pageSize: pageSize.toString() } };

    if (filter && filter.length > 0) {
      header.params['personNumber'] = filter;
    }

    if (filterParams) {
      if (filterParams.personType) {
        header.params['personType'] = filterParams.personType;
      }
    }

    return this.http.get(this.apiUrl, header);
  }

  getContacts(filters: PoDisclaimer[], page = 1, pageSize = 20, personNumber: number, header = true):
    Observable<TotvsResponse<IPerson>> {
    let url = `${this.apiUrl}/${personNumber}${this.apiContact}?pageSize=${pageSize}&page=${page}`;

    if (filters && filters.length > 0) {
      const urlParams = new Array<string>();

      filters.map(filter => {
        urlParams.push(`${filter.property}=${btoa(filter.value)}`);
      });

      url = `${url}&${urlParams.join('&')}`;
    }

    if (header) {
      return this.http.get<TotvsResponse<IPerson>>(url, this.headers);
    } else {
      return this.http.get<TotvsResponse<IPerson>>(url);
    }

  }

  getContactById(personNumber: number, contactName: string, expandables: string[]): Observable<IPerson> {
    let lstExpandables = this.getExpandables(expandables);
    if (lstExpandables !== '') { lstExpandables = `&${lstExpandables}`; }

    return this.http.get<IPerson>(
      `${this.apiUrl}/${personNumber}${this.apiContact}/${personNumber}/${contactName}?${lstExpandables}`, this.headers);
  }

  createContact(model: IContact): Observable<IPerson> {
    return this.http.post<IPerson>(`${this.apiUrl}/${model.personNumber}${this.apiContact}`, model, this.headers);
  }

  updateContact(model: IContact): Observable<IPerson> {
    return this.http.put<IPerson>(
      `${this.apiUrl}/${model.personNumber}${this.apiContact}/${model.personNumber}/${btoa(model.contactName)}`, model, this.headers);
  }

  deleteContact(personNumber: number, contactName: string): Observable<object> {
    return this.http.delete(`${this.apiUrl}/${personNumber}${this.apiContact}/${personNumber}/${contactName}`, this.headers);
  }

  getUrl(urlBase: string, filters: PoDisclaimer[], expandables: string[],
         page: number, pageSize: number): string {
    const urlParams = new Array<string>();

    urlParams.push(`pageSize=${pageSize}`);
    urlParams.push(`page=${page}`);

    const lstExpandables = this.getExpandables(expandables);
    if (lstExpandables !== '') { urlParams.push(lstExpandables); }

    if (filters && filters.length > 0) {
      filters.map(filter => {
        urlParams.push(`${filter.property}=${filter.value}`);
      });
    }

    return `${urlBase}?${urlParams.join('&')}`;
  }

  getExpandables(expandables: string[]): string {
    let lstExpandables = '';

    if (expandables && expandables.length > 0) {
      expandables.map(expandable => {
        if (expandable !== '' && this.expandables.includes(expandable)) {
          if (lstExpandables !== '') { lstExpandables = `${lstExpandables},`; }
          lstExpandables = `${lstExpandables}${expandable}`;
        }
      });
    }

    if (lstExpandables !== '') { lstExpandables = `expand=${lstExpandables}`; }

    return lstExpandables;
  }

}
