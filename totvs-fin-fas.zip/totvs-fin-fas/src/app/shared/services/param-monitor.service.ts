import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { PoDisclaimer } from '@po-ui/ng-components';

import { TotvsResponse } from 'dts-backoffice-util';

import { IParamMonitor, ParamMonitor} from '../model/param-monitor.model';

@Injectable()
export class ParamMonitorService {

    // FIXME: Change to the backend service URL
    private headers = { headers: { 'X-PO-Screen-Lock': 'true' } };
    private apiUrl = '/dts/datasul-rest/resources/prg/fin/v1/monitorParameters';

    constructor(private http: HttpClient) { }

    query(filters: PoDisclaimer[], page = 1, pageSize = 20,
          screenLoading = false): Observable<TotvsResponse<IParamMonitor>> {

        let url = `${this.apiUrl}?pageSize=${pageSize}&page=${page}`;

        if (filters && filters.length > 0) {

            const urlParams = new Array<string>();

            filters.forEach(filter => {
                urlParams.push(`${filter.property}=${filter.value}`);
            });

            url = `${url}&${urlParams.join('&')}`;
        }

        if (screenLoading) {
            return this.http.get<TotvsResponse<IParamMonitor>>(url, this.headers);
        } else {
            return this.http.get<TotvsResponse<IParamMonitor>>(url);
        }

    }

    getById(companyCode: string, userCode: string): Observable<IParamMonitor> {
        const idParam = btoa(companyCode + ';' + userCode);
        return this.http.get<IParamMonitor>(`${this.apiUrl}/${idParam}`);
    }

    create(model: IParamMonitor): Observable<IParamMonitor> {
        return this.http.post<IParamMonitor>(`${this.apiUrl}`, model, this.headers);
    }

    update(model: IParamMonitor): Observable<IParamMonitor> {
      return this.http.put<IParamMonitor>(`${this.apiUrl}/${ParamMonitor.getInternalId(model)}`, model, this.headers);
  }

    delete(model: IParamMonitor): Observable<object> {
      return this.http.delete(`${this.apiUrl}/${ParamMonitor.getInternalId(model)}`, this.headers);
    }

}
