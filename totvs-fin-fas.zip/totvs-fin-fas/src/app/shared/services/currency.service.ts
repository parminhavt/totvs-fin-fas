import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { PoDisclaimer } from '@po-ui/ng-components';

import { TotvsResponse } from 'dts-backoffice-util';

import { ICurrency } from '../model/currency.model';
import { Observable } from 'rxjs';

@Injectable()
export class CurrencyService {

    private headers = { headers: { 'X-PO-Screen-Lock': 'true' } };
    private apiUrl = '/dts/datasul-rest/resources/prg/fin/v1/currency';

    constructor(private http: HttpClient) { }

    query(filters: PoDisclaimer[], page = 1, pageSize = 20, screenLoading = false): Observable<TotvsResponse<ICurrency>> {

        let url = `${this.apiUrl}?pageSize=${pageSize}&page=${page}`;

        if (filters && filters.length > 0) {

            const urlParams = new Array<string>();

            filters.forEach(filter => {
                urlParams.push(`${filter.property}=${filter.value}`);
            });

            url = `${url}&${urlParams.join('&')}`;
        }

        if (screenLoading) {
            return this.http.get<TotvsResponse<ICurrency>>(url, this.headers);
        } else {
            return this.http.get<TotvsResponse<ICurrency>>(url);
        }

    }

    getObjectByValue(id: string): Observable<ICurrency> {
        return this.http.get<ICurrency>(`${this.apiUrl}/${id}`, this.headers);
    }

    getFilteredData(filter: string, page: number, pageSize: number): Observable<any> {
        const header = { params: { page: page.toString(), pageSize: pageSize.toString() } };

        if (filter && filter.length > 0) {
            header.params['code'] = filter;
        }

        return this.http.get(`${this.apiUrl}`, header);
    }
}
