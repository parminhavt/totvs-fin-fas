import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { TotvsResponse } from 'dts-backoffice-util';
import { PoDisclaimer, PoLookupFilteredItemsParams } from '@po-ui/ng-components';
import { ITransferParams } from '../model/transfer-params.model';
import { IAssetTransferParams } from '../model/asset-transfer-params.model';


@Injectable()
export class AssetTransferService {

  private headers = { headers: { 'X-PO-Screen-Lock': 'true' } };
  private apiUrl = '/dts/datasul-rest/resources/prg/fin/v1/assetTransfer';


  constructor(private http: HttpClient) { }

  query(filters: PoDisclaimer[], page = 1, pageSize = 20, screenLoading = false): Observable<TotvsResponse<IAssetTransferParams>> {
    let url = '';
    const urlParams = new Array<string>();

    urlParams.push(`pageSize=${pageSize}`);
    urlParams.push(`page=${page}`);

    if (filters && filters.length > 0) {
      filters.forEach(filter => {
        urlParams.push(`${filter.property}=${filter.value}`);
      });
    }

    url = `${this.apiUrl}?${urlParams.join('&')}`;

    if (screenLoading) {
      return this.http.get<TotvsResponse<IAssetTransferParams>>(url, this.headers);
    } else {
      return this.http.get<TotvsResponse<IAssetTransferParams>>(url);
    }
  }

  getById(id: string, screenLoading = false): Observable<IAssetTransferParams> {
    if (screenLoading) {
      return this.http.get<IAssetTransferParams>(`${this.apiUrl}/${id}`, this.headers);
    } else {
      return this.http.get<IAssetTransferParams>(`${this.apiUrl}/${id}`);
    }

  }

  executeTransfer(model: ITransferParams, typeTransfer: number): Observable<ITransferParams> {
    if (typeTransfer === 1 ){
      return this.http.post<ITransferParams>(`${this.apiUrl}/executeInternalTransfer`, model, this.headers);
    } else if (typeTransfer === 2 ){
      return this.http.post<ITransferParams>(`${this.apiUrl}/executeExternalTransfer`, model, this.headers);
    }
  }

  searchPreviousRequests(model: ITransferParams): Observable<ITransferParams> {
    return this.http.post<ITransferParams>(`${this.apiUrl}/searchPreviousRequests`, model, this.headers);
  }



}
