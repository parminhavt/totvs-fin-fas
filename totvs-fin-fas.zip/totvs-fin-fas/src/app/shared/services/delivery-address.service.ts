import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { TotvsResponse } from 'dts-backoffice-util';
import { PoDisclaimer } from '@po-ui/ng-components';
import { IDeliveryAddress } from '../model/delivery-address.model';


@Injectable()
export class DeliveryAddressService {

    private headers = { headers: { 'X-PO-Screen-Lock': 'true' } };
    private apiUrl = '/dts/datasul-rest/resources/prg/fin/v1/deliveryAddress';

    constructor(private http: HttpClient) { }

    query(filters: PoDisclaimer[], page = 1, pageSize = 20, screenLoading = false): Observable<TotvsResponse<IDeliveryAddress>> {
        let url = '';
        const urlParams = new Array<string>();

        urlParams.push(`pageSize=${pageSize}`);
        urlParams.push(`page=${page}`);

        if (filters && filters.length > 0) {
            filters.forEach(filter => {
                urlParams.push(`${filter.property}=${filter.value}`);
            });
        }

        url = `${this.apiUrl}?${urlParams.join('&')}`;

        if (screenLoading) {
            return this.http.get<TotvsResponse<IDeliveryAddress>>(url, this.headers);
        } else {
            return this.http.get<TotvsResponse<IDeliveryAddress>>(url);
        }
    }

    getById(id: string, screenLoading = false): Observable<IDeliveryAddress> {
      if (screenLoading) {
          return this.http.get<IDeliveryAddress>(`${this.apiUrl}/${id}`, this.headers);
      } else {
          return this.http.get<IDeliveryAddress>(`${this.apiUrl}/${id}`);
      }

    }


}
