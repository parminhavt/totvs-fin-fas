import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { TotvsResponse } from 'dts-backoffice-util';
import { PoDisclaimer } from '@po-ui/ng-components';
import { IDemobilizationReason } from '../model/demobilization-reason.model';


@Injectable()
export class DemobilizationReasonService {

    private headers = { headers: { 'X-PO-Screen-Lock': 'true' } };
    private apiUrl = '/dts/datasul-rest/resources/prg/fin/v1/demobilizationReason';

    constructor(private http: HttpClient) { }

    query(filters: PoDisclaimer[], page = 1, pageSize = 20, screenLoading = false): Observable<TotvsResponse<IDemobilizationReason>> {
        let url = '';
        const urlParams = new Array<string>();

        urlParams.push(`pageSize=${pageSize}`);
        urlParams.push(`page=${page}`);

        if (filters && filters.length > 0) {
            filters.forEach(filter => {
                urlParams.push(`${filter.property}=${filter.value}`);
            });
        }

        url = `${this.apiUrl}?${urlParams.join('&')}`;

        if (screenLoading) {
            return this.http.get<TotvsResponse<IDemobilizationReason>>(url, this.headers);
        } else {
            return this.http.get<TotvsResponse<IDemobilizationReason>>(url);
        }
    }

    getById(id: string, screenLoading = false): Observable<IDemobilizationReason> {
      if (screenLoading) {
          return this.http.get<IDemobilizationReason>(`${this.apiUrl}/${id}`, this.headers);
      } else {
          return this.http.get<IDemobilizationReason>(`${this.apiUrl}/${id}`);
      }

    }


}
