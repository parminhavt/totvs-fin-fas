import { IAssetTransferParams } from './asset-transfer-params.model';

export interface ITransferParams {

  transferType: number; /** Tipo transferência */
  transactionDate: Date;  /*Data da transferência*/
  requestPlanCostCenter: string;
  requestCostCenter: string;
  requestBusinessUnit: string;
  location: string;
  requestBranch: string;
  demobReason: string; /** Código do motivo da Transferencia */
  economicIndicator: string;
  invoiceValue: number;
  jobScheduleID: string;
  assetTransferParams: Array<IAssetTransferParams>;
}

export class TransferParams implements ITransferParams {

  transferType: number; /** Tipo transferência */
  transactionDate: Date;  /*Data da transferência*/
  requestPlanCostCenter: string;
  requestCostCenter: string;
  requestBusinessUnit: string;
  location: string;
  requestBranch: string;
  demobReason: string; /** Código do motivo da Transferencia */
  economicIndicator: string;
  invoiceValue: number;
  jobScheduleID: string;
  assetTransferParams: Array<IAssetTransferParams>;

  constructor(values: object = {}) {
    Object.assign(this, values);
  }

  public get $transferType(): number { return this.transferType; }
  public set $transferType(transferType: number) { this.transferType = transferType; }

  public get $transactionDate(): Date { return this.transactionDate; }
  public set $transactionDate(transactionDate: Date) { this.transactionDate = transactionDate; }

  public get $requestPlanCostCenter(): string { return this.requestPlanCostCenter; }
  public set $requestPlanCostCenter(requestPlanCostCenter: string) { this.requestPlanCostCenter = requestPlanCostCenter; }

  public get $requestCostCenter(): string { return this.requestCostCenter; }
  public set $requestCostCenter(requestCostCenter: string) { this.requestCostCenter = requestCostCenter; }

  public get $requestBusinessUnit(): string { return this.requestBusinessUnit; }
  public set $requestBusinessUnit(requestBusinessUnit: string) { this.requestBusinessUnit = requestBusinessUnit; }

  public get $requestBranch(): string { return this.requestBranch; }
  public set $requestBranch(requestBranch: string) { this.requestBranch = requestBranch; }

  public get $demobReason(): string { return this.demobReason; }
  public set $demobReason(demobReason: string) { this.demobReason = demobReason; }

  public get $economicIndicator(): string { return this.economicIndicator; }
  public set $economicIndicator(economicIndicator: string) { this.economicIndicator = economicIndicator; }

  public get $invoiceValue(): number { return this.invoiceValue; }
  public set $invoiceValue(invoiceValue: number) { this.invoiceValue = invoiceValue; }

  public get $jobScheduleID(): string { return this.jobScheduleID; }
  public set $jobScheduleID(jobScheduleID: string) { this.jobScheduleID = jobScheduleID; }

  public get $assetTransferParams(): Array<IAssetTransferParams>
  { return this.assetTransferParams; }
  public set $assetTransferParams(assetTransferParams: Array<IAssetTransferParams>)
  { this.assetTransferParams = assetTransferParams; }


  static of(json: any = {}) {
    return new TransferParams(json);
  }

  static empty() {
    return new TransferParams();
  }

  static fromJson(json: Array<any> = []) {

    const items: Array<ITransferParams> = [];

    for (const values of json) {
      items.push(new TransferParams(values));
    }

    return items;
  }

}
