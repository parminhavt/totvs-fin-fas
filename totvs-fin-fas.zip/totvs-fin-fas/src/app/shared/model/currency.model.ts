export interface ICurrency {
    code: string;
    description: string;
    symbol: string;
}

export class Currency implements ICurrency {
    code: string;
    description: string;
    symbol: string;

    constructor(values: object = {}) {
        Object.assign(this, values);
    }

    public get $code(): string {
        return this.code;
    }

    public set $code(value: string) {
      this.code = value;
    }

    public get $description(): string {
        return this.description;
    }

    public set $description(value: string) {
      this.description = value;
    }

    public get $symbol(): string {
        return this.symbol;
    }

    public set $symbol(value: string) {
        this.symbol = value;
    }

    static of(json: any = {}) {
        return new Currency(json);
    }

    static empty() {
        return new Currency();
    }

    static fromJson(json: Array<any> = []) {

        const items: Array<ICurrency> = [];

        for (const values of json) {
            items.push(new Currency(values));
        }

        return items;
    }

}
