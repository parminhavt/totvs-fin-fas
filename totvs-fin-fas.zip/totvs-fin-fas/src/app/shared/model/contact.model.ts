export interface IContact {
    personNumber: number;
    contactName: string;
    personName: string;
    contactPhone: string;
    contactExternalPhone: string;
    contactFax: string;
    contactExternalFax: string;
    modemCode: string;
    externalModemCode: string;
    email: string;
    description: string;
    fisicPersonNumber: number;
    federalID: string;
    countryCode: string;
    sentPriority: string;
    updateUser: string;
    updateDate: Date;
    updateHour: string;
    updateEMS2: boolean;
    addressName: string;
    addressComplement: string;
    neighborhood: string;
    mailboxCode: string;
    cityName: string;
    countyName: string;
    stateCode: string;
    cep: string;
    addressText: string;
    version: number;
    applicationType: string;
    areaCode: string;
    officeCode: string;
}

export class Contact implements IContact {
    personNumber: number;
    contactName: string;
    personName: string;
    contactPhone: string;
    contactExternalPhone: string;
    contactFax: string;
    contactExternalFax: string;
    modemCode: string;
    externalModemCode: string;
    email: string;
    description: string;
    fisicPersonNumber: number;
    federalID: string;
    countryCode: string;
    sentPriority: string;
    updateUser: string;
    updateDate: Date;
    updateHour: string;
    updateEMS2: boolean;
    addressName: string;
    addressComplement: string;
    neighborhood: string;
    mailboxCode: string;
    cityName: string;
    countyName: string;
    stateCode: string;
    cep: string;
    addressText: string;
    version: number;
    applicationType: string;
    areaCode: string;
    officeCode: string;

    constructor(values: Object = {}) {
        Object.assign(this, values);
    }

    get $personNumber(): number { return this.personNumber; }
    get $contactName(): string { return this.contactName; }
    get $personName(): string { return this.personName; }
    get $contactPhone(): string { return this.contactPhone; }
    get $contactExternalPhone(): string { return this.contactExternalPhone; }
    get $contactFax(): string { return this.contactFax; }
    get $contactExternalFax(): string { return this.contactExternalFax; }
    get $modemCode(): string { return this.modemCode; }
    get $externalModemCode(): string { return this.externalModemCode; }
    get $email(): string { return this.email; }
    get $description(): string { return this.description; }
    get $fisicPersonNumber(): number { return this.fisicPersonNumber; }
    get $federalID(): string { return this.federalID; }
    get $countryCode(): string { return this.countryCode; }
    get $sentPriority(): string { return this.sentPriority; }
    get $updateUser(): string { return this.updateUser; }
    get $updateDate(): Date { return this.updateDate; }
    get $updateHour(): string { return this.updateHour; }
    get $updateEMS2(): boolean { return this.updateEMS2; }
    get $addressName(): string { return this.addressName; }
    get $addressComplement(): string { return this.addressComplement; }
    get $neighborhood(): string { return this.neighborhood; }
    get $mailboxCode(): string { return this.mailboxCode; }
    get $cityName(): string { return this.cityName; }
    get $countyName(): string { return this.countyName; }
    get $stateCode(): string { return this.stateCode; }
    get $cep(): string { return this.cep; }
    get $addressText(): string { return this.addressText; }
    get $version(): number { return this.version; }
    get $applicationType(): string { return this.applicationType; }
    get $areaCode(): string { return this.areaCode; }
    get $officeCode(): string { return this.officeCode; }

    set $personNumber(value: number) { this.personNumber = value; }
    set $contactName(value: string) { this.contactName = value; }
    set $personName(value: string) { this.personName = value; }
    set $contactPhone(value: string) { this.contactPhone = value; }
    set $contactExternalPhone(value: string) { this.contactExternalPhone = value; }
    set $contactFax(value: string) { this.contactFax = value; }
    set $contactExternalFax(value: string) { this.contactExternalFax = value; }
    set $modemCode(value: string) { this.modemCode = value; }
    set $externalModemCode(value: string) { this.externalModemCode = value; }
    set $email(value: string) { this.email = value; }
    set $description(value: string) { this.description = value; }
    set $fisicPersonNumber(value: number) { this.fisicPersonNumber = value; }
    set $federalID(value: string) { this.federalID = value; }
    set $countryCode(value: string) { this.countryCode = value; }
    set $sentPriority(value: string) { this.sentPriority = value; }
    set $updateUser(value: string) { this.updateUser = value; }
    set $updateDate(value: Date) { this.updateDate = value; }
    set $updateHour(value: string) { this.updateHour = value; }
    set $updateEMS2(value: boolean) { this.updateEMS2 = value; }
    set $addressName(value: string) { this.addressName = value; }
    set $addressComplement(value: string) { this.addressComplement = value; }
    set $neighborhood(value: string) { this.neighborhood = value; }
    set $mailboxCode(value: string) { this.mailboxCode = value; }
    set $cityName(value: string) { this.cityName = value; }
    set $countyName(value: string) { this.countyName = value; }
    set $stateCode(value: string) { this.stateCode = value; }
    set $cep(value: string) { this.cep = value; }
    set $addressText(value: string) { this.addressText = value; }
    set $version(value: number) { this.version = value; }
    set $applicationType(value: string) { this.applicationType = value; }
    set $areaCode(value: string) { this.areaCode = value; }
    set $officeCode(value: string) { this.officeCode = value; }

    static of(json: any = {}) {
        return new Contact(json);
    }

    static empty() {
        return new Contact();
    }

    static fromJson(json: Array<any> = []) {

        const items: Array<IContact> = [];

        for (const values of json) {
            items.push(new Contact(values));
        }

        return items;
    }

}
