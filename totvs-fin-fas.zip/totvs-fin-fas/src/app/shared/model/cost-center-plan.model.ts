export interface ICostCenterPlan {
    costCenterPlanCode: string;
    costCenterPlanName: string;
}

export class CostCenterPlan implements ICostCenterPlan {

    costCenterPlanCode: string;
    costCenterPlanName: string;

    constructor(values: object = {}) {
        Object.assign(this, values);
    }

    public get $costCenterPlanCode(): string {
        return this.costCenterPlanCode;
    }

    public set $costCenterPlanCode(costCenterPlanCode: string) {
        this.costCenterPlanCode = costCenterPlanCode;
    }

    public get $costCenterPlanName(): string {
        return this.costCenterPlanName;
    }

    public set $costCenterPlanName(costCenterPlanName: string) {
        this.costCenterPlanName = costCenterPlanName;
    }

    static of(json: any = {}) {
        return new CostCenterPlan(json);
    }

    static empty() {
        return new CostCenterPlan();
    }

    static fromJson(json: Array<any> = []) {

        const items: Array<ICostCenterPlan> = [];

        for (const values of json) {
            items.push(new CostCenterPlan(values));
        }

        return items;
    }

}

