export interface IDeliveryAddress {
  comporatePerson: number;
  address: string;
  addressName: string;
  neighborhood: string;
  city: string;
  country: string;


}

export class DeliveryAddress implements IDeliveryAddress {

  comporatePerson: number;
  address: string;
  addressName: string;
  neighborhood: string;
  city: string;
  country: string;

  constructor(values: object = {}) {
    Object.assign(this, values);
  }

  public get $comporatePerson(): number {
    return this.comporatePerson;
  }

  public set $comporatePerson(comporatePerson: number) {
    this.comporatePerson = comporatePerson;
  }

  public get $address(): string {
    return this.address;
  }

  public set $address(address: string) {
    this.address = address;
  }

  public get $addressName(): string {
    return this.addressName;
  }

  public set $addressName(addressName: string) {
    this.addressName = addressName;
  }

  public get $neighborhood(): string {
    return this.neighborhood;
  }

  public set $neighborhood(neighborhood: string) {
    this.neighborhood = neighborhood;
  }

  public get $city(): string {
    return this.city;
  }

  public set $city(city: string) {
    this.city = city;
  }

  public get $country(): string {
    return this.country;
  }

  public set $country(country: string) {
    this.country = country;
  }

  static getInternalId(item: IDeliveryAddress): string {

    return item.comporatePerson + ';' +  item.address.toString();
  }


  static of(json: any = {}) {
    return new DeliveryAddress(json);
  }

  static empty() {
    return new DeliveryAddress();
  }

  static fromJson(json: Array<any> = []) {

    const items: Array<IDeliveryAddress> = [];

    for (const values of json) {
      items.push(new DeliveryAddress(values));
    }

    return items;
  }

}
