export interface IParamMonitor {
  companyCode: string;
  userCode: string;
  serverCode: string;
}

export class ParamMonitor implements IParamMonitor {

  companyCode: string;
  userCode: string;
  serverCode: string;

  constructor(values: object = {}) {
    Object.assign(this, values);
  }

  public get $companyCode(): string {
    return this.companyCode;
  }

  public set $companyCode(value: string) {
    this.companyCode = value;
  }

  public get $userCode(): string {
    return this.userCode;
  }

  public set $userCode(value: string) {
    this.userCode = value;
  }

  public get $serverCode(): string {
    return this.serverCode;
  }

  public set $serverCode(value: string) {
    this.serverCode = value;
  }

  static of(json: any = {}) {
    return new ParamMonitor(json);
  }

  static empty() {
    return new ParamMonitor();
  }

  static fromJson(json: Array<any> = []) {

    const items: Array<IParamMonitor> = [];

    for (const values of json) {
      items.push(new ParamMonitor(values));
    }

    return items;
  }

  static getInternalId(item: IParamMonitor): string {
    return btoa(item.companyCode + ';' +
      item.userCode);
  }

}

