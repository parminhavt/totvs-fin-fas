export interface ICompany {
    companyCode: string;
    companyName: string;
    companyShortName: string;
}

export class Company implements ICompany {

    companyCode: string;
    companyName: string;
    companyShortName: string;

    constructor(values: object = {}) {
        Object.assign(this, values);
    }

    public get $companyCode(): string {
        return this.companyCode;
    }

    public set $companyCode(value: string) {
      this.companyCode = value;
    }

    public get $companyName(): string {
        return this.companyName;
    }

    public set $companyName(value: string) {
      this.companyName = value;
    }

    public get $companyShortName(): string {
        return this.companyShortName;
    }

    public set $companyShortName(value: string) {
        this.companyShortName = value;
    }

    static of(json: any = {}) {
        return new Company(json);
    }

    static empty() {
        return new Company();
    }

    static fromJson(json: Array<any> = []) {

        const items: Array<ICompany> = [];

        for (const values of json) {
            items.push(new Company(values));
        }

        return items;
    }

}

