export interface ILocation {
    branch: string;
    locationSup: string;
    locationCode: string;
    locationName: string;
}

export class Location implements ILocation {
  branch: string;
  locationSup: string;
  locationCode: string;
  locationName: string;

    constructor(values: object = {}) {
        Object.assign(this, values);
    }

    get $branch(): string { return this.branch; }
    set $branch(value: string) { this.branch = value; }

    get $locationSup(): string { return this.locationSup; }
    set $locationSup(value: string) { this.locationSup = value; }

    get $locationCode(): string { return this.locationCode; }
    set $locationCode(value: string) { this.locationCode = value; }

    get $locationName(): string { return this.locationName; }
    set $locationName(value: string) { this.locationName = value; }

    static getInternalId(item: ILocation): string {

      return item.branch + ';' +  item.locationCode;
    }


    static of(json: any = {}) {
        return new Location(json);
    }

    static empty() {
        return new Location();
    }

    static fromJson(json: Array<any> = []) {

        const items: Array<ILocation> = [];

        for (const values of json) {
            items.push(new Location(values));
        }

        return items;
    }

}
