export interface IAssetInventoryActive {

  numIdSequence: number;
  desInventory: string;
  statusInventory: string;
  userCodeResponsible:string;
	approvalManager:boolean;
  assetWritteOff:boolean;
  lockMovement:boolean;
  assetInventoryOverDue:boolean;
  sendTermManager:boolean;
  sendTerm:boolean;
  companyCode: string;
  inventorySequence: number;
  inventoryPlanCostCenter: string;
  inventoryCostCenter: string;
  assetAccount: string;
  assetSequence: number;
  incorporationSequence: number;
  date: Date;
  descAssetAccount: string;
  descAssetNumber: string;
  errorDescription: string;

	/*
ind_situacao_invent	
dat_ini_valid	dateFinal
dat_fim_valid	dateInitial
cod_usuar_responsavel	
log_aprovacao_gestor

log_bloqueia_movto	
log_consider_bxado	
log_bens_invent_vcto	
log_env_termo_fim_gestao	
log_env_termo_fim_cd	    
des_planilhja	
des_termo_finm	

cod_empresa
cod_estab
cod_unid_negoc
cod_plano_ccusto
cod_ccusto
cod_cta_pat
cod_localizacao
*/




}

export class AssetInventoryActive implements IAssetInventoryActive {

  numIdSequence: number;
  desInventory: string;
  statusInventory: string;
  userCodeResponsible:string;
	approvalManager:boolean;
  assetWritteOff:boolean;
  lockMovement:boolean;
  assetInventoryOverDue:boolean;
  sendTermManager:boolean;
  sendTerm:boolean;
  companyCode: string;
  inventorySequence: number;
  inventoryPlanCostCenter: string;
  inventoryCostCenter: string;
  assetAccount: string;
  assetSequence: number;
  incorporationSequence: number;
  date: Date;
  descAssetAccount: string;
  descAssetNumber: string;
  errorDescription: string;
  
  /*requestIdSequence: number;
  companyCode: string;
  InventorySequence: number;
  requestBranch: string;
  requestPlanCostCenter: string;
  requestCostCenter: string;
  assetAccount: string;
  assetNumber: number;
  assetSequence: number;
  incorporationSequence: number;
  date: Date;
  descAssetAccount: string;
  descAssetNumber: string;
  operationRequest: string;
  statusInventory: string;
  branch: string;
  errorDescription: string;*/

  constructor(values: object = {}) {
    Object.assign(this, values);
  }

  public get $numIdSequence(): number { return this.numIdSequence; }
  public set $numIdSequence(numIdSequence: number) { this.numIdSequence = numIdSequence; }

  public get $inventorySequence(): number { return this.inventorySequence; }
  public set $inventorySequence(inventorySequence: number) { this.inventorySequence = inventorySequence; }


  public get $companyCode(): string { return this.companyCode; }
  public set $companyCode(companyCode: string) { this.companyCode = companyCode; }

  public get $desInventory(): string { return this.desInventory; }
  public set $desInventory(desInventory: string) { this.desInventory = desInventory; }

  public get $inventoryCostCenter(): string { return this.inventoryCostCenter; }
  public set $inventoryCostCenter(inventoryCostCenter: string) { this.inventoryCostCenter = inventoryCostCenter; }

  public get $assetAccount(): string { return this.assetAccount; }
  public set $assetAccount(assetAccount: string) { this.assetAccount = assetAccount; }

  public get $assetSequence(): number { return this.assetSequence; }
  public set $assetSequence(assetSequence: number) { this.assetSequence = assetSequence; }

  public get $incorporationSequence(): number { return this.incorporationSequence; }
  public set $incorporationSequence(incorporationSequence: number) { this.incorporationSequence = incorporationSequence; }

  public get $date(): Date { return this.date; }
  public set $date(date: Date) { this.date = date; }

  public get $descAssetAccount(): string { return this.descAssetAccount; }
  public set $descAssetAccount(descAssetAccount: string) { this.descAssetAccount = descAssetAccount; }

  public get $sendTermManager(): boolean { return this.sendTermManager; }
  public set $sendTermManager(sendTermManager: boolean) { this.sendTermManager = sendTermManager; }

  
  public get $assetInventoryOverDue(): boolean { return this.assetInventoryOverDue; }
  public set $assetInventoryOverDue(assetInventoryOverDue: boolean) { this.assetInventoryOverDue = assetInventoryOverDue; }

  
  public get $lockMovement(): boolean { return this.lockMovement; }
  public set $lockMovement(lockMovement: boolean) { this.lockMovement = lockMovement; }


  public get $assetWritteOff(): boolean { return this.assetWritteOff; }
  public set $assetWritteOff(assetWritteOff: boolean) { this.assetWritteOff = assetWritteOff; }

  public get $sendTerm(): boolean { return this.sendTerm; }
  public set $sendTerm(sendTerm: boolean) { this.sendTerm = sendTerm; }

  
  public get $statusInventory(): string { return this.statusInventory; }
  public set $statusInventory(statusInventory: string) { this.statusInventory = statusInventory; }

  public get $userCodeResponsible(): string { return this.userCodeResponsible; }
  public set $userCodeResponsible(userCodeResponsible: string) { this.userCodeResponsible = userCodeResponsible; }

  public get $errorDescription(): string { return this.errorDescription; }
  public set $errorDescription(errorDescription: string) { this.errorDescription = errorDescription; }

  static of(json: any = {}) {
    return new AssetInventoryActive(json);
  }

  static empty() {
    return new AssetInventoryActive();
  }

  static fromJson(json: Array<any> = []) {

    const items: Array<IAssetInventoryActive> = [];

    for (const values of json) {
      items.push(new AssetInventoryActive(values));
    }

    return items;
  }

}
