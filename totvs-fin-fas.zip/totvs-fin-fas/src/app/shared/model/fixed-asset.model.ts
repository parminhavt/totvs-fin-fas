export interface IFixedAsset {
  assetCode: string;
  fixedNumber: number;
  fixedSeqNumber: number;
  descFixedAsset: string;
  desAssetSeqNumber: string;

}

export class FixedAsset implements IFixedAsset {

  assetCode: string;
  fixedNumber: number;
  fixedSeqNumber: number;
  descFixedAsset: string;
  desAssetSeqNumber: string;

  constructor(values: object = {}) {
      Object.assign(this, values);
  }

  public get $assetCode(): string {
      return this.assetCode;
  }

  public set $assetCode(assetCode: string) {
      this.assetCode = assetCode;
  }

  public get $fixedNumber(): number {
      return this.fixedNumber;
  }

  public set $fixedNumber(fixedNumber: number) {
      this.fixedNumber = fixedNumber;
  }

  public get $fixedSeqNumber(): number {
      return this.fixedSeqNumber;
  }

  public set $fixedSeqNumber(fixedSeqNumber: number) {
      this.fixedSeqNumber = fixedSeqNumber;
  }

  public get $descFixedAsset(): string {
      return this.descFixedAsset;
  }

  public set $descFixedAsset(descFixedAsset: string) {
      this.descFixedAsset = descFixedAsset;
  }

  public get $desAssetSeqNumber(): string {
    return this.desAssetSeqNumber;
}

public set $desAssetSeqNumber(desAssetSeqNumber: string) {
    this.desAssetSeqNumber = desAssetSeqNumber;
}

  static of(json: any = {}) {
      return new FixedAsset(json);
  }

  static empty() {
      return new FixedAsset();
  }

  static fromJson(json: Array<any> = []) {

      const items: Array<IFixedAsset> = [];

      for (const values of json) {
          items.push(new FixedAsset(values));
      }

      return items;
  }

}
