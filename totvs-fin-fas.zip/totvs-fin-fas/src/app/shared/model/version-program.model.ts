export interface IVersionProgram {
  programCode: string;
  versionCode: string;
}

export class VersionProgram implements IVersionProgram {

  programCode: string;
  versionCode: string;

  constructor(values: object = {}) {
    Object.assign(this, values);
  }

  public get $programCode(): string {
    return this.programCode;
  }

  public set $programCode(value: string) {
    this.programCode = value;
  }

  public get $versionCode(): string {
    return this.versionCode;
  }

  public set $versionCode(value: string) {
    this.versionCode = value;
  }


  static of(json: any = {}) {
    return new VersionProgram(json);
  }

  static empty() {
    return new VersionProgram();
  }

  static fromJson(json: Array<any> = []) {

    const items: Array<IVersionProgram> = [];

    for (const values of json) {
      items.push(new VersionProgram(values));
    }

    return items;
  }

}

