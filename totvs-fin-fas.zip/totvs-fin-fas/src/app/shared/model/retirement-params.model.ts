import { IAssetRetirementParams } from './asset-retirement-params.model';

export interface IRetirementParams {

  retirementType: string; /** Tipo baixa */
  retirementReason: number; /** Motivo Baixa */
  transactionDate: Date;  /*Data da baixa*/
  demobReason: string; /** Código do motivo da Baixa */
  scenario: string;
  economicIndicator: string;
  originalValue: number;
  quantityValue: number;
  percentageValue: number;
  personType: number;
  person: number;
  address: string;
  invoiceValue: number;
  idiRetirementType: number;
  jobScheduleID: string;
  assetRetirementParams: Array<IAssetRetirementParams>;
}

export class RetirementParams implements IRetirementParams {

  retirementType: string; /** Tipo baixa */
  retirementReason: number; /** Motivo Baixa */
  transactionDate: Date;  /*Data da baixa*/
  demobReason: string; /** Código do motivo da Baixa */
  scenario: string;
  economicIndicator: string;
  originalValue: number;
  quantityValue: number;
  percentageValue: number;
  personType: number;
  person: number;
  address: string;
  invoiceValue: number;
  idiRetirementType: number;
  jobScheduleID: string;
  assetRetirementParams: Array<IAssetRetirementParams>;

  constructor(values: object = {}) {
    Object.assign(this, values);
  }

  public get $retirementType(): string { return this.retirementType; }
  public set $retirementType(retirementType: string) { this.retirementType = retirementType; }

  public get $retirementReason(): number { return this.retirementReason; }
  public set $retirementReason(retirementReason: number) { this.retirementReason = retirementReason; }

  public get $transactionDate(): Date { return this.transactionDate; }
  public set $transactionDate(transactionDate: Date) { this.transactionDate = transactionDate; }

  public get $demobReason(): string { return this.demobReason; }
  public set $demobReason(demobReason: string) { this.demobReason = demobReason; }

  public get $economicIndicator(): string { return this.economicIndicator; }
  public set $economicIndicator(economicIndicator: string) { this.economicIndicator = economicIndicator; }

  public get $scenario(): string { return this.scenario; }
  public set $scenario(scenario: string) { this.scenario = scenario; }


  public get $originalValue(): number { return this.originalValue; }
  public set $originalValue(originalValue: number) { this.originalValue = originalValue; }

  public get $quantityValue(): number { return this.quantityValue; }
  public set $quantityValue(quantityValue: number) { this.quantityValue = quantityValue; }

  public get $percentageValue(): number { return this.percentageValue; }
  public set $percentageValue(percentageValue: number) { this.percentageValue = percentageValue; }

  public get $personType(): number { return this.personType; }
  public set $personType(personType: number) { this.personType = personType; }

  public get $person(): number { return this.person; }
  public set $person(person: number) { this.person = person; }

  public get $address(): string { return this.address; }
  public set $address(address: string) { this.address = address; }

  public get $invoiceValue(): number { return this.invoiceValue; }
  public set $invoiceValue(invoiceValue: number) { this.invoiceValue = invoiceValue; }

  public get $idiRetirementType(): number { return this.idiRetirementType; }
  public set $idiRetirementType(idiRetirementType: number) { this.idiRetirementType = idiRetirementType; }

  public get $jobScheduleID(): string { return this.jobScheduleID; }
  public set $jobScheduleID(jobScheduleID: string) { this.jobScheduleID = jobScheduleID; }

  public get $assetRetirementParams(): Array<IAssetRetirementParams>
  { return this.assetRetirementParams; }
  public set $assetRetirementParams(assetRetirementParams: Array<IAssetRetirementParams>)
  { this.assetRetirementParams = assetRetirementParams; }


  static retireTypeLabelList(literals: {}) {
    return [
      { idiRetirementType: 1, label: literals['byValue'] },
      { idiRetirementType: 2, label: literals['byPercent'] },
      { idiRetirementType: 3, label: literals['byAmount'] }
    ];
  }


  static of(json: any = {}) {
    return new RetirementParams(json);
  }

  static empty() {
    return new RetirementParams();
  }

  static fromJson(json: Array<any> = []) {

    const items: Array<IRetirementParams> = [];

    for (const values of json) {
      items.push(new RetirementParams(values));
    }

    return items;
  }

}
