import { IContact } from './contact.model';

export interface IPerson {
    personNumber: number;
    personType: number;
    personName: string;
    federalID: string;
    country: string;
    city: string;
    state: string;
    contacts: Array<IContact>;
}

export class Person implements IPerson {
    personNumber: number;
    personType: number;
    personName: string;
    federalID: string;
    country: string;
    city: string;
    state: string;
    contacts: Array<IContact>;

    constructor(values: object = {}) {
        Object.assign(this, values);
    }

    get $personNumber(): number { return this.personNumber; }
    set $personNumber(value: number) { this.personNumber = value; }

    get $personType(): number { return this.personType; }
    set $personType(value: number) { this.personType = value; }

    get $personName(): string { return this.personName; }
    set $personName(value: string) { this.personName = value; }

    get $federalID(): string { return this.federalID; }
    set $federalID(value: string) { this.federalID = value; }

    get $country(): string { return this.country; }
    set $country(value: string) { this.country = value; }

    get $city(): string { return this.city; }
    set $city(value: string) { this.city = value; }

    get $state(): string { return this.state; }
    set $state(value: string) { this.state = value; }

    get $contacts(): Array<IContact> { return this.contacts; }
    set $contacts(value: Array<IContact>) { this.contacts = value; }

    static personTypeLabelList(literals: {}) {
        return [
            { value: 1, color: 'success', label: literals['personTypeNatural'] },
            { value: 2, color: 'warning', label: literals['personTypeCorporate'] }
        ];
    }

    static of(json: any = {}) {
        return new Person(json);
    }

    static empty() {
        return new Person();
    }

    static fromJson(json: Array<any> = []) {

        const items: Array<IPerson> = [];

        for (const values of json) {
            items.push(new Person(values));
        }

        return items;
    }

}
