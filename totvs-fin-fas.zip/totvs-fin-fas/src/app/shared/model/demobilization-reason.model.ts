export interface IDemobilizationReason {
  reasonCode: string;
  descReason: string;
  retire: boolean;
  transfer: boolean;
  genReceipt: boolean;

}

export class DemobilizationReason implements IDemobilizationReason {

  reasonCode: string;
  descReason: string;
  retire: boolean;
  transfer: boolean;
  genReceipt: boolean;

  constructor(values: object = {}) {
    Object.assign(this, values);
  }

  public get $reasonCode(): string {
    return this.reasonCode;
  }

  public set $reasonCode(reasonCode: string) {
    this.reasonCode = reasonCode;
  }

  public get $retire(): boolean {
    return this.retire;
  }

  public set $retire(retire: boolean) {
    this.retire = retire;
  }

  public get $transfer(): boolean {
    return this.transfer;
  }

  public set $transfer(transfer: boolean) {
    this.transfer = transfer;
  }
  public get $genReceipt(): boolean {
    return this.genReceipt;
  }

  public set $genReceipt(genReceipt: boolean) {
    this.genReceipt = genReceipt;
  }

  static of(json: any = {}) {
    return new DemobilizationReason(json);
  }

  static empty() {
    return new DemobilizationReason();
  }

  static fromJson(json: Array<any> = []) {

    const items: Array<IDemobilizationReason> = [];

    for (const values of json) {
      items.push(new DemobilizationReason(values));
    }

    return items;
  }

}
