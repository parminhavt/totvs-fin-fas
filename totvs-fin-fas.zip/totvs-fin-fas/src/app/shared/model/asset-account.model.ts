export interface IAssetAccount {
  assetCode: string;
  calcGroupCode: string;
  assetGroupCode: string;
  descAsset: string;
  fisicControl: boolean;
  entryGlControl: boolean;

}

export class AssetAccount implements IAssetAccount {

  assetCode: string;
  calcGroupCode: string;
  assetGroupCode: string;
  descAsset: string;
  fisicControl: boolean;
  entryGlControl: boolean;

  constructor(values: object = {}) {
      Object.assign(this, values);
  }

  public get $assetCode(): string {
      return this.assetCode;
  }

  public set $assetCode(assetCode: string) {
      this.assetCode = assetCode;
  }

  public get $calcGroupCode(): string {
      return this.calcGroupCode;
  }

  public set $calcGroupCode(calcGroupCode: string) {
      this.calcGroupCode = calcGroupCode;
  }

  public get $assetGroupCode(): string {
      return this.assetGroupCode;
  }

  public set $assetGroupCode(assetGroupCode: string) {
      this.assetGroupCode = assetGroupCode;
  }

  public get $descAsset(): string {
      return this.descAsset;
  }

  public set $descAsset(descAsset: string) {
      this.descAsset = descAsset;
  }

  public get $fisicControl(): boolean {
      return this.fisicControl;
  }

  public set $fisicControl(fisicControl: boolean) {
      this.fisicControl = fisicControl;
  }

  public get $entryGlControl(): boolean {
    return this.entryGlControl;
}

public set $entryGlControl(entryGlControl: boolean) {
    this.entryGlControl = entryGlControl;
}

  static of(json: any = {}) {
      return new AssetAccount(json);
  }

  static empty() {
      return new AssetAccount();
  }

  static fromJson(json: Array<any> = []) {

      const items: Array<IAssetAccount> = [];

      for (const values of json) {
          items.push(new AssetAccount(values));
      }

      return items;
  }

}
