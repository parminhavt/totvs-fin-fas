import { IAssetIntegrationMonitorMovements } from './asset-integration-monitor-movements.model';

export interface IAssetIntegrationMonitorDetail {
  requestIdSequence: number;
  companyCode: string;
  requestSequence: number;
  assetAccount: string;
  assetNumber: number;
  assetSequence: number;
  descAssetAccount: string;
  desAssetNumber: string;
  operationRequest: string;
  statusRequest: string;
  operation: number;
  status: number;
  date: Date;
  reason: string;
  assetValue: number;
  assetBranch: string;
  assetCostCenter: string;
  assetBusinessUnit: string;
  assetDesc: string;
  assetLastDate: Date;
  assetPlate: string;
  invoice: string;
  image: string;
  error: boolean;
  errorDescription: string;
  userCode: string;
  executionRequest: number;
  assetMovements: Array<IAssetIntegrationMonitorMovements>;

}

export class AssetIntegrationMonitorDetail implements IAssetIntegrationMonitorDetail {
  requestIdSequence: number;
  companyCode: string;
  requestSequence: number;
  assetAccount: string;
  assetNumber: number;
  assetSequence: number;
  descAssetAccount: string;
  desAssetNumber: string;
  operationRequest: string;
  statusRequest: string;
  operation: number;
  status: number;
  date: Date;
  reason: string;
  assetValue: number;
  assetBranch: string;
  assetCostCenter: string;
  assetBusinessUnit: string;
  assetDesc: string;
  assetLastDate: Date;
  assetPlate: string;
  invoice: string;
  image: string;
  error: boolean;
  errorDescription: string;
  userCode: string;
  executionRequest: number;
  assetMovements: Array<IAssetIntegrationMonitorMovements>;

  constructor(values: object = {}) {
    Object.assign(this, values);
  }

  public get $requestIdSequence(): number { return this.requestIdSequence; }
  public set $requestIdSequence(requestIdSequence: number) { this.requestIdSequence = requestIdSequence; }

  public get $companyCode(): string { return this.companyCode; }
  public set $companyCode(companyCode: string) { this.companyCode = companyCode; }

  public get $requestSequence(): number { return this.requestSequence; }
  public set $requestSequence(requestSequence: number) { this.requestSequence = requestSequence; }

  public get $assetAccount(): string { return this.assetAccount; }
  public set $assetAccount(assetAccount: string) { this.assetAccount = assetAccount; }

  public get $assetNumber(): number { return this.assetNumber; }
  public set $assetNumber(assetNumber: number) { this.assetNumber = assetNumber; }

  public get $assetSequence(): number { return this.assetSequence; }
  public set $assetSequence(assetSequence: number) { this.assetSequence = assetSequence; }

  public get $descAssetAccount(): string { return this.descAssetAccount; }
  public set $descAssetAccount(descAssetAccount: string) { this.descAssetAccount = descAssetAccount; }

  public get $desAssetNumber(): string { return this.desAssetNumber; }
  public set $desAssetNumber(desAssetNumber: string) { this.desAssetNumber = desAssetNumber; }

  public get $operationRequest(): string { return this.operationRequest; }
  public set $operationRequest(operationRequest: string) { this.operationRequest = operationRequest; }

  public get $statusRequest(): string { return this.statusRequest; }
  public set $statusRequest(statusRequest: string) { this.statusRequest = statusRequest; }

  public get $operation(): number { return this.operation; }
  public set $operation(operation: number) { this.operation = operation; }

  public get $status(): number { return this.status; }
  public set $status(status: number) { this.status = status; }

  public get $date(): Date { return this.date; }
  public set $date(date: Date) { this.date = date; }

  public get $reason(): string { return this.reason; }
  public set $reason(reason: string) { this.reason = reason; }

  public get $assetValue(): number { return this.assetValue; }
  public set $assetValue(assetValue: number) { this.assetValue = assetValue; }

  public get $assetBranch(): string { return this.assetBranch; }
  public set $assetBranch(assetBranch: string) { this.assetBranch = assetBranch; }

  public get $assetCostCenter(): string { return this.assetCostCenter; }
  public set $assetCostCenter(assetCostCenter: string) { this.assetCostCenter = assetCostCenter; }

  public get $assetBusinessUnit(): string { return this.assetBusinessUnit; }
  public set $assetBusinessUnit(assetBusinessUnit: string) { this.assetBusinessUnit = assetBusinessUnit; }

  public get $assetDesc(): string { return this.assetDesc; }
  public set $assetDesc(assetDesc: string) { this.assetDesc = assetDesc; }

  public get $assetLastDate(): Date { return this.assetLastDate; }
  public set $assetLastDate(assetLastDate: Date) { this.assetLastDate = assetLastDate; }

  public get $assetPlate(): string { return this.assetPlate; }
  public set $assetPlate(assetPlate: string) { this.assetPlate = assetPlate; }

  public get $invoice(): string { return this.invoice; }
  public set $invoice(invoice: string) { this.invoice = invoice; }

  public get $image(): string { return this.image; }
  public set $image(image: string) { this.image = image; }

  public get $error(): boolean { return this.error; }
  public set $error(error: boolean) { this.error = error; }

  public get $errorDescription(): string { return this.errorDescription; }
  public set $errorDescription(errorDescription: string) { this.errorDescription = errorDescription; }

  public get $userCode(): string { return this.userCode; }
  public set $userCode(userCode: string) { this.userCode = userCode; }

  public get $executionRequest(): number { return this.executionRequest; }
  public set $executionRequest(executionRequest: number) { this.executionRequest = executionRequest; }

  public get $assetMovements(): Array<IAssetIntegrationMonitorMovements> { return this.assetMovements; }
  public set $assetMovements(assetMovements: Array<IAssetIntegrationMonitorMovements>) { this.assetMovements = assetMovements; }

  static operationRequestLabelList(literals: {}) {
    return [
      { value: 1, label: literals['retirement'] },
      { value: 2, label: literals['transfer'] },
      { value: 3, label: literals['dateRefesh'] },
      { value: 4, label: literals['requestCancel'] }
    ];
  }

  static statusRequestLabelList(literals: {}) {
    return [
      { value: 1, label: literals['pending'], color: 'color-08' },
      { value: 2, label: literals['completed'], color: 'color-11' },
      { value: 3, label: literals['canceled'], color: 'color-07' },
      { value: 4, label: literals['scheduled'], color: 'color-02' }
    ];
  }

  static of(json: any = {}) {
    return new AssetIntegrationMonitorDetail(json);
  }

  static empty() {
    return new AssetIntegrationMonitorDetail();
  }

  static fromJson(json: Array<any> = []) {

    const items: Array<IAssetIntegrationMonitorDetail> = [];

    for (const values of json) {
      items.push(new AssetIntegrationMonitorDetail(values));
    }

    return items;
  }

}
