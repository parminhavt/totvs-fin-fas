
export interface IAssetRetirementParams {
  solicitId: number;
  assetCode: string;
  fixedNumber: number;
  fixedSeqNumber: number;
  descFixedAsset: string;
  desAssetSeqNumber: string;
  descAssetAccount: string;
  date: Date;
  reason: string;
  value: number;
  quantity: number;
  percentage: number;
  assetDesc: string;
  assetLastDate: Date;
  assetPlate: string;
  retirementReason: string;
  retirementType: string;
  currency: string;
  scenario: string;
  demobReason: string;
  personType: string;
  person: number;
  address: string;
  invoiceValue: number;

}

export class AssetRetirementParams implements IAssetRetirementParams {

  solicitId: number;
  assetCode: string;
  fixedNumber: number;
  fixedSeqNumber: number;
  descFixedAsset: string;
  desAssetSeqNumber: string;
  descAssetAccount: string;
  date: Date;
  reason: string;
  value: number;
  quantity: number;
  percentage: number;
  assetDesc: string;
  assetLastDate: Date;
  assetPlate: string;
  retirementReason: string;
  retirementType: string;
  currency: string;
  scenario: string;
  demobReason: string;
  personType: string;
  person: number;
  address: string;
  invoiceValue: number;

  constructor(values: object = {}) {
    Object.assign(this, values);
  }

  public get $solicitId(): number { return this.solicitId; }
  public set $solicitId(solicitId: number) { this.solicitId = solicitId; }

  public get $assetCode(): string { return this.assetCode; }
  public set $assetCode(assetCode: string) { this.assetCode = assetCode; }

  public get $fixedNumber(): number { return this.fixedNumber; }
  public set $fixedNumber(fixedNumber: number) { this.fixedNumber = fixedNumber; }

  public get $fixedSeqNumber(): number { return this.fixedSeqNumber; }
  public set $fixedSeqNumber(fixedSeqNumber: number) { this.fixedSeqNumber = fixedSeqNumber; }

  public get $descFixedAsset(): string { return this.descFixedAsset; }
  public set $descFixedAsset(descFixedAsset: string) { this.descFixedAsset = descFixedAsset; }

  public get $desAssetSeqNumber(): string { return this.desAssetSeqNumber; }
  public set $desAssetSeqNumber(desAssetSeqNumber: string) { this.desAssetSeqNumber = desAssetSeqNumber; }

  public get $descAssetAccount(): string { return this.descAssetAccount; }
  public set $descAssetAccount(descAssetAccount: string) { this.descAssetAccount = descAssetAccount; }

  public get $date(): Date { return this.date; }
  public set $date(date: Date) { this.date = date; }

  public get $reason(): string { return this.reason; }
  public set $reason(reason: string) { this.reason = reason; }

  public get $value(): number { return this.value; }
  public set $value(value: number) { this.value = value; }

  public get $quantity(): number { return this.quantity; }
  public set $quantity(quantity: number) { this.quantity = quantity; }

  public get $percentage(): number { return this.percentage; }
  public set $percentage(percentage: number) { this.percentage = percentage; }

  public get $assetDesc(): string { return this.assetDesc; }
  public set $assetDesc(assetDesc: string) { this.assetDesc = assetDesc; }

  public get $assetLastDate(): Date { return this.assetLastDate; }
  public set $assetLastDate(assetLastDate: Date) { this.assetLastDate = assetLastDate; }

  public get $assetPlate(): string { return this.assetPlate; }
  public set $assetPlate(assetPlate: string) { this.assetPlate = assetPlate; }

  public get $retirementReason(): string { return this.retirementReason; }
  public set $retirementReason(retirementReason: string) { this.retirementReason = retirementReason; }

  public get $currency(): string { return this.currency; }
  public set $currency(currency: string) { this.currency = currency; }

  public get $retirementType(): string { return this.retirementType; }
  public set $retirementType(retirementType: string) { this.retirementType = retirementType; }

  public get $scenario(): string { return this.scenario; }
  public set $scenario(scenario: string) { this.scenario = scenario; }

  public get $demobReason(): string { return this.demobReason; }
  public set $demobReason(demobReason: string) { this.demobReason = demobReason; }

  public get $personType(): string { return this.personType; }
  public set $personType(personType: string) { this.personType = personType; }

  public get $person(): number { return this.person; }
  public set $person(person: number) { this.person = person; }

  public get $address(): string { return this.address; }
  public set $address(address: string) { this.address = address; }

  public get $invoiceValue(): number { return this.invoiceValue; }
  public set $invoiceValue(invoiceValue: number) { this.invoiceValue = invoiceValue; }


  static operationRequestLabelList(literals: {}) {
    return [
      { value: 1, label: literals['retirement'] },
      { value: 2, label: literals['transfer'] },
      { value: 3, label: literals['dateRefesh'] },
      { value: 4, label: literals['requestCancel'] }
    ];
  }


  static of(json: any = {}) {
    return new AssetRetirementParams(json);
  }

  static empty() {
    return new AssetRetirementParams();
  }

  static fromJson(json: Array<any> = []) {

    const items: Array<IAssetRetirementParams> = [];

    for (const values of json) {
      items.push(new AssetRetirementParams(values));
    }

    return items;
  }

}
