export interface IAssetTransferParams {
  solicitId: number;
  assetCode: string;
  fixedNumber: number;
  fixedSeqNumber: number;
  descFixedAsset: string;
  desAssetSeqNumber: string;
  descAssetAccount: string;
  assetDesc: string;
  assetBranch: string;
  assetCostCenterPlan: string;
  assetCostCenter: string;
  assetBusinessUnit: string;
  planCostCenter: string; /** Plano que o bem será tranferido */
  costCenter: string; /** Centro de custo que o bem será transferido */
  businessUnit: string;
  branch: string;
  transactionDate: Date;  /*Data da transferência*/
  requestPlanCostCenter: string; /** Plano que o bem está */
  requestCostCenter: string; /** Centro de custo que o bem está */
  requestBranch: string; /** estabelecimento que o bem está */
  requestBusinessUnit: string; /** UN que o bem está */


}

export class AssetTransferParams implements IAssetTransferParams {

  solicitId: number;
  assetCode: string;
  fixedNumber: number;
  fixedSeqNumber: number;
  descFixedAsset: string;
  desAssetSeqNumber: string;
  descAssetAccount: string;
  assetDesc: string;
  assetBranch: string;
  assetCostCenterPlan: string;
  assetCostCenter: string;
  assetBusinessUnit: string;
  planCostCenter: string;
  costCenter: string;
  businessUnit: string;
  branch: string;
  transactionDate: Date;  /*Data da transferência*/
  requestPlanCostCenter: string;
  requestCostCenter: string;
  requestBranch: string;
  requestBusinessUnit: string;


  constructor(values: object = {}) {
    Object.assign(this, values);
  }

  public get $solicitId(): number { return this.solicitId; }
  public set $solicitId(solicitId: number) { this.solicitId = solicitId; }

  public get $assetCode(): string { return this.assetCode; }
  public set $assetCode(assetCode: string) { this.assetCode = assetCode; }

  public get $fixedNumber(): number { return this.fixedNumber; }
  public set $fixedNumber(fixedNumber: number) { this.fixedNumber = fixedNumber; }

  public get $fixedSeqNumber(): number { return this.fixedSeqNumber; }
  public set $fixedSeqNumber(fixedSeqNumber: number) { this.fixedSeqNumber = fixedSeqNumber; }

  public get $descFixedAsset(): string { return this.descFixedAsset; }
  public set $descFixedAsset(descFixedAsset: string) { this.descFixedAsset = descFixedAsset; }

  public get $desAssetSeqNumber(): string { return this.desAssetSeqNumber; }
  public set $desAssetSeqNumber(desAssetSeqNumber: string) { this.desAssetSeqNumber = desAssetSeqNumber; }

  public get $descAssetAccount(): string { return this.descAssetAccount; }
  public set $descAssetAccount(descAssetAccount: string) { this.descAssetAccount = descAssetAccount; }

  public get $assetBranch(): string { return this.assetBranch; }
  public set $assetBranch(assetBranch: string) { this.assetBranch = assetBranch; }

  public get $assetCostCenterPlan(): string { return this.assetCostCenterPlan; }
  public set $assetCostCenterPlan(assetCostCenterPlan: string) { this.assetCostCenterPlan = assetCostCenterPlan; }

  public get $assetCostCenter(): string { return this.assetCostCenter; }
  public set $assetCostCenter(assetCostCenter: string) { this.assetCostCenter = assetCostCenter; }

  public get $assetBusinessUnit(): string { return this.assetBusinessUnit; }
  public set $assetBusinessUnit(assetBusinessUnit: string) { this.assetBusinessUnit = assetBusinessUnit; }

  public get $planCostCenter(): string { return this.planCostCenter; }
  public set $planCostCenter(planCostCenter: string) { this.planCostCenter = planCostCenter; }

  public get $costCenter(): string { return this.costCenter; }
  public set $costCenter(costCenter: string) { this.costCenter = costCenter; }

  public get $businessUnit(): string { return this.businessUnit; }
  public set $businessUnit(businessUnit: string) { this.businessUnit = businessUnit; }

  public get $branch(): string { return this.branch; }
  public set $branch(branch: string) { this.branch = branch; }

  public get $transactionDate(): Date { return this.transactionDate; }
  public set $transactionDate(transactionDate: Date) { this.transactionDate = transactionDate; }

  public get $requestPlanCostCenter(): string { return this.requestPlanCostCenter; }
  public set $requestPlanCostCenter(requestPlanCostCenter: string) { this.requestPlanCostCenter = requestPlanCostCenter; }

  public get $requestCostCenter(): string { return this.requestCostCenter; }
  public set $requestCostCenter(requestCostCenter: string) { this.requestCostCenter = requestCostCenter; }

  public get $requestBranch(): string { return this.requestBranch; }
  public set $requestBranch(requestBranch: string) { this.requestBranch = requestBranch; }

  public get $requestBusinessUnit(): string { return this.requestBusinessUnit; }
  public set $requestBusinessUnit(requestBusinessUnit: string) { this.requestBusinessUnit = requestBusinessUnit; }

  static of(json: any = {}) {
    return new AssetTransferParams(json);
  }

  static empty() {
    return new AssetTransferParams();
  }

  static fromJson(json: Array<any> = []) {

    const items: Array<IAssetTransferParams> = [];

    for (const values of json) {
      items.push(new AssetTransferParams(values));
    }

    return items;
  }

}
