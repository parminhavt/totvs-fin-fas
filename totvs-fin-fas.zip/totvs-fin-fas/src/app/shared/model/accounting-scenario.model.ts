export interface IAccountingScenario {
    accountingScenarioCode: string;
    accountingScenarioDescription: string;
    accountPeriodAmount: number;
    noteDescription: string;
    inactiveScenario: boolean;
    ifrsScenarioDate: Date;
}

export class AccountingScenario implements IAccountingScenario {

    accountingScenarioCode: string;
    accountingScenarioDescription: string;
    accountPeriodAmount: number;
    noteDescription: string;
    inactiveScenario: boolean;
    ifrsScenarioDate: Date;

    constructor(values: object = {}) {
        Object.assign(this, values);
    }

    public get $accountingScenarioCode(): string {
        return this.accountingScenarioCode;
    }

    public set $accountingScenarioCode(value: string) {
      this.accountingScenarioCode = value;
    }

    public get $accountingScenarioDescription(): string {
        return this.accountingScenarioDescription;
    }

    public set $accountingScenarioDescription(value: string) {
      this.accountingScenarioDescription = value;
    }

    public get $accountPeriodAmount(): number {
        return this.accountPeriodAmount;
    }

    public set $accountPeriodAmount(value: number) {
      this.accountPeriodAmount = value;
    }

    public get $noteDescription(): string {
        return this.noteDescription;
    }

    public set $noteDescription(value: string) {
      this.noteDescription = value;
    }

    public get $inactiveScenario(): boolean {
        return this.inactiveScenario;
    }

    public set $inactiveScenario(value: boolean) {
      this.inactiveScenario = value;
    }

    public get $ifrsScenarioDate(): Date {
        return this.ifrsScenarioDate;
    }

    public set $ifrsScenarioDate(value: Date) {
        this.ifrsScenarioDate = value;
    }

    static of(json: any = {}) {
        return new AccountingScenario(json);
    }

    static empty() {
        return new AccountingScenario();
    }

    static fromJson(json: Array<any> = []) {

        const items: Array<IAccountingScenario> = [];

        for (const values of json) {
            items.push(new AccountingScenario(values));
        }

        return items;
    }

}

