export interface ICostCenter {
    costCenterCode: string;
    costCenterName: string;
}

export class CostCenter implements ICostCenter {

    costCenterCode: string;
    costCenterName: string;

    constructor(values: object = {}) {
        Object.assign(this, values);
    }

    public get $costCenterName(): string {
        return this.costCenterName;
    }

    public set $costCenterName(costCenterName: string) {
        this.costCenterName = costCenterName;
    }

    public get $costCenterCode(): string {
        return this.costCenterCode;
    }

    public set $costCenterCode(costCenterCode: string) {
        this.costCenterCode = costCenterCode;
    }

    static of(json: any = {}) {
        return new CostCenter(json);
    }

    static empty() {
        return new CostCenter();
    }

    static fromJson(json: Array<any> = []) {

        const items: Array<ICostCenter> = [];

        for (const values of json) {
            items.push(new CostCenter(values));
        }

        return items;
    }

}

