export interface IServerRpw {
  id: number;
  name: string;
  admin: string; // supervisor do servidor rpw
  isDefault: boolean;
}

export class ServerRpw implements IServerRpw {
  id: number;
  name: string;
  admin: string;
  isDefault: boolean;

  constructor(values: object = {}) {
    Object.assign(this, values);
  }

  get $id() { return this.id; }
  set $id(id: number) { this.id = id; }

  get $name() { return this.name; }
  set $name(name: string) { this.name = name; }

  get $admin() { return this.admin; }
  set $admin(admin: string) { this.admin = admin; }

  get $isDefault() { return this.isDefault; }
  set $isDefault(isDefault: boolean) { this.isDefault = isDefault; }

  static of(json: any = {}) {
    return new ServerRpw(json);
  }

  static empty() {
    return new ServerRpw();
  }

  static fromJson(json: Array<any> = []) {

    const items: Array<IServerRpw> = [];

    for (const values of json) {
      items.push(new ServerRpw(values));
    }

    return items;
  }

}
