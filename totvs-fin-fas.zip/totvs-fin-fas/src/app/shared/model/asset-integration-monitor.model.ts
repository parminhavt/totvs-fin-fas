export interface IAssetIntegrationMonitor {

  requestIdSequence: number;
  companyCode: string;
  requestSequence: number;
  requestBranch: string;
  requestPlanCostCenter: string;
  requestCostCenter: string;
  assetAccount: string;
  assetNumber: number;
  assetSequence: number;
  incorporationSequence: number;
  date: Date;
  descAssetAccount: string;
  descAssetNumber: string;
  operationRequest: string;
  statusRequest: string;
  branch: string;
  errorDescription: string;

}

export class AssetIntegrationMonitor implements IAssetIntegrationMonitor {

  requestIdSequence: number;
  companyCode: string;
  requestSequence: number;
  requestBranch: string;
  requestPlanCostCenter: string;
  requestCostCenter: string;
  assetAccount: string;
  assetNumber: number;
  assetSequence: number;
  incorporationSequence: number;
  date: Date;
  descAssetAccount: string;
  descAssetNumber: string;
  operationRequest: string;
  statusRequest: string;
  branch: string;
  errorDescription: string;

  constructor(values: object = {}) {
    Object.assign(this, values);
  }

  public get $requestIdSequence(): number { return this.requestIdSequence; }
  public set $requestIdSequence(requestIdSequence: number) { this.requestIdSequence = requestIdSequence; }

  public get $companyCode(): string { return this.companyCode; }
  public set $companyCode(companyCode: string) { this.companyCode = companyCode; }

  public get $requestSequence(): number { return this.requestSequence; }
  public set $requestSequence(requestSequence: number) { this.requestSequence = requestSequence; }

  public get $requestBranch(): string { return this.requestBranch; }
  public set $requestBranch(requestBranch: string) { this.requestBranch = requestBranch; }

  public get $requestPlanCostCenter(): string { return this.requestPlanCostCenter; }
  public set $requestPlanCostCenter(requestPlanCostCenter: string) { this.requestPlanCostCenter = requestPlanCostCenter; }

  public get $requestCostCenter(): string { return this.requestCostCenter; }
  public set $requestCostCenter(requestCostCenter: string) { this.requestCostCenter = requestCostCenter; }

  public get $assetAccount(): string { return this.assetAccount; }
  public set $assetAccount(assetAccount: string) { this.assetAccount = assetAccount; }

  public get $assetNumber(): number { return this.assetNumber; }
  public set $assetNumber(assetNumber: number) { this.assetNumber = assetNumber; }

  public get $assetSequence(): number { return this.assetSequence; }
  public set $assetSequence(assetSequence: number) { this.assetSequence = assetSequence; }

  public get $incorporationSequence(): number { return this.incorporationSequence; }
  public set $incorporationSequence(incorporationSequence: number) { this.incorporationSequence = incorporationSequence; }

  public get $date(): Date { return this.date; }
  public set $date(date: Date) { this.date = date; }

  public get $descAssetAccount(): string { return this.descAssetAccount; }
  public set $descAssetAccount(descAssetAccount: string) { this.descAssetAccount = descAssetAccount; }

  public get $descAssetNumber(): string { return this.descAssetNumber; }
  public set $descAssetNumber(descAssetNumber: string) { this.descAssetNumber = descAssetNumber; }

  public get $operationRequest(): string { return this.operationRequest; }
  public set $operationRequest(operationRequest: string) { this.operationRequest = operationRequest; }

  public get $statusRequest(): string { return this.statusRequest; }
  public set $statusRequest(statusRequest: string) { this.statusRequest = statusRequest; }

  public get $branch(): string { return this.branch; }
  public set $branch(branch: string) { this.branch = branch; }

  public get $errorDescription(): string { return this.errorDescription; }
  public set $errorDescription(errorDescription: string) { this.errorDescription = errorDescription; }

  static of(json: any = {}) {
    return new AssetIntegrationMonitor(json);
  }

  static empty() {
    return new AssetIntegrationMonitor();
  }

  static fromJson(json: Array<any> = []) {

    const items: Array<IAssetIntegrationMonitor> = [];

    for (const values of json) {
      items.push(new AssetIntegrationMonitor(values));
    }

    return items;
  }

}
