export interface IAssetIntegrationMonitorMovements {

  requestIdSequence: number;
  companyCode: string;
  requestSequence: number;
  requestBranch: string;
  requestPlanCostCenter: string;
  requestCostCenter: string;
  assetAccount: string;
  assetNumber: number;
  assetSequence: number;
  incorporationSequence: number;
  date: Date;
  movementDate: Date;
  transCalcFixed: string;
  origCalcFixed: string;
  accountingScenario: string;
  economicPurpose: string;
  originMovementValue: number;
  originMovementPercValue: number;
  originMovementAmount: number;
  planCostCenter: string;
  costCenter: string;
  businessUnit: string;
  branch: string;
  idiTransCalcFixed: number;
  idiOrigCalcFixed: number;



}

export class AssetIntegrationMonitorMovements implements IAssetIntegrationMonitorMovements {

  requestIdSequence: number;
  companyCode: string;
  requestSequence: number;
  requestBranch: string;
  requestPlanCostCenter: string;
  requestCostCenter: string;
  assetAccount: string;
  assetNumber: number;
  assetSequence: number;
  incorporationSequence: number;
  date: Date;
  movementDate: Date;
  transCalcFixed: string;
  origCalcFixed: string;
  accountingScenario: string;
  economicPurpose: string;
  originMovementValue: number;
  originMovementPercValue: number;
  originMovementAmount: number;
  planCostCenter: string;
  costCenter: string;
  businessUnit: string;
  branch: string;
  idiTransCalcFixed: number;
  idiOrigCalcFixed: number;

  constructor(values: object = {}) {
    Object.assign(this, values);
  }

  public get $requestIdSequence(): number { return this.requestIdSequence; }
  public set $requestIdSequence(requestIdSequence: number) { this.requestIdSequence = requestIdSequence; }

  public get $companyCode(): string { return this.companyCode; }
  public set $companyCode(companyCode: string) { this.companyCode = companyCode; }

  public get $requestSequence(): number { return this.requestSequence; }
  public set $requestSequence(requestSequence: number) { this.requestSequence = requestSequence; }

  public get $requestBranch(): string { return this.requestBranch; }
  public set $requestBranch(requestBranch: string) { this.requestBranch = requestBranch; }

  public get $requestPlanCostCenter(): string { return this.requestPlanCostCenter; }
  public set $requestPlanCostCenter(requestPlanCostCenter: string) { this.requestPlanCostCenter = requestPlanCostCenter; }

  public get $requestCostCenter(): string { return this.requestCostCenter; }
  public set $requestCostCenter(requestCostCenter: string) { this.requestCostCenter = requestCostCenter; }

  public get $assetAccount(): string { return this.assetAccount; }
  public set $assetAccount(assetAccount: string) { this.assetAccount = assetAccount; }

  public get $assetNumber(): number { return this.assetNumber; }
  public set $assetNumber(assetNumber: number) { this.assetNumber = assetNumber; }

  public get $assetSequence(): number { return this.assetSequence; }
  public set $assetSequence(assetSequence: number) { this.assetSequence = assetSequence; }

  public get $incorporationSequence(): number { return this.incorporationSequence; }
  public set $incorporationSequence(incorporationSequence: number) { this.incorporationSequence = incorporationSequence; }

  public get $date(): Date { return this.date; }
  public set $date(date: Date) { this.date = date; }

  public get $movementDate(): Date { return this.movementDate; }
  public set $movementDate(movementDate: Date) { this.movementDate = movementDate; }

  public get $transCalcFixed(): string { return this.transCalcFixed; }
  public set $transCalcFixed(transCalcFixed: string) { this.transCalcFixed = transCalcFixed; }

  public get $origCalcFixed(): string { return this.origCalcFixed; }
  public set $origCalcFixed(origCalcFixed: string) { this.origCalcFixed = origCalcFixed; }

  public get $accountingScenario(): string { return this.accountingScenario; }
  public set $accountingScenario(accountingScenario: string) { this.accountingScenario = accountingScenario; }

  public get $economicPurpose(): string { return this.economicPurpose; }
  public set $economicPurpose(economicPurpose: string) { this.economicPurpose = economicPurpose; }

  public get $originMovementValue(): number { return this.originMovementValue; }
  public set $originMovementValue(originMovementValue: number) { this.originMovementValue = originMovementValue; }

  public get $originMovementPercValue(): number { return this.originMovementPercValue; }
  public set $originMovementPercValue(originMovementPercValue: number) { this.originMovementPercValue = originMovementPercValue; }

  public get $originMovementAmount(): number { return this.originMovementAmount; }
  public set $originMovementAmount(originMovementAmount: number) { this.originMovementAmount = originMovementAmount; }

  public get $planCostCenter(): string { return this.planCostCenter; }
  public set $planCostCenter(planCostCenter: string) { this.planCostCenter = planCostCenter; }

  public get $costCenter(): string { return this.costCenter; }
  public set $costCenter(costCenter: string) { this.costCenter = costCenter; }

  public get $businessUnit(): string { return this.businessUnit; }
  public set $businessUnit(businessUnit: string) { this.businessUnit = businessUnit; }

  public get $branch(): string { return this.branch; }
  public set $branch(branch: string) { this.branch = branch; }

  public get $idiTransCalcFixed(): number { return this.idiTransCalcFixed; }
  public set $idiTransCalcFixed(idiTransCalcFixed: number) { this.idiTransCalcFixed = idiTransCalcFixed; }

  public get $idiOrigCalcFixed(): number { return this.idiOrigCalcFixed; }
  public set $idiOrigCalcFixed(idiOrigCalcFixed: number) { this.idiOrigCalcFixed = idiOrigCalcFixed; }

  static transCalcFixedLabelList(literals: {}) {
    return [
      { value: 1, label: literals['implem'] },
      { value: 2, label: literals['retirement'] },
      { value: 3, label: literals['priceRestatement'] },
      { value: 4, label: literals['deprec'] },
      { value: 4, label: literals['amortizat'] },
      { value: 4, label: literals['distrib'] }
    ];
  }

  static origCalcFixedLabelList(literals: {}) {
    return [
      { value: 1, label: literals['acquisit'] },
      { value: 2, label: literals['reactivation'] },
      { value: 3, label: literals['idle'] },
      { value: 4, label: literals['sale'] },
      { value: 5, label: literals['damage'] },
      { value: 6, label: literals['transfer'] },
      { value: 7, label: literals['dismember'] },
      { value: 8, label: literals['union'] },
      { value: 9, label: literals['reassessmt'] },
      { value: 10, label: literals['adition'] },
      { value: 11, label: literals['improvement'] },
      { value: 12, label: literals['insur'] },
      { value: 13, label: literals['leasing'] },
      { value: 14, label: literals['update'] },
      { value: 15, label: literals['immobilized'] },
      { value: 16, label: literals['rateDifference'] },
      { value: 17, label: literals['returnMov'] },
      { value: 18, label: literals['rewRating'] },
      { value: 19, label: literals['apport'] }
    ];
  }


  static of(json: any = {}) {
    return new AssetIntegrationMonitorMovements(json);
  }

  static empty() {
    return new AssetIntegrationMonitorMovements();
  }

  static fromJson(json: Array<any> = []) {

    const items: Array<IAssetIntegrationMonitorMovements> = [];

    for (const values of json) {
      items.push(new AssetIntegrationMonitorMovements(values));
    }

    return items;
  }

}

