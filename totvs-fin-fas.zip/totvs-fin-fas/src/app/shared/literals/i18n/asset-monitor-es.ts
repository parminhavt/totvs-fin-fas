export const assetMonitorEs = {
  assetIntegrationMonitor: 'Monitor de Integración Ativo Fijo',
  integrationMonitor: 'Monitor de Integración',
  inventoryActive: 'Inventario Ativo',
  notifications: 'Notificaciones',
  generalParams: 'Parametros generales',
  executionServer: 'Servidor RPW',
  code: 'Código',
  name: 'Descripción',
  admin: 'Administrador',
  monitor: 'Monitor',
  return: 'Vuelve',
  requestMovement: 'Movimientar Solicitación',
  sameTypeRequest: 'Solo seleccione solicitudes del mismo tipo para mover!',
  requestIsNotPending: 'La solicitud no se puede mover porque el estado no está pendiente!'
};
