export const assetInventoryActiveEn = {
  assetInventoryActive: 'Asset Inventory Active',
  inventoryActive: 'InventoryActive',
  inventory: 'Inventory',
  notifications: 'Notifications',
  generalParams: 'General Parameters',
  executionServer: 'RPW Server',
  code: 'Code',
  name: 'Description',
  admin: 'Administrator',
  monitor: 'Monitor',
  return: 'Return',
  requestMovement: 'Request Movement',
  sameTypeRequest: 'Only select requests of the same type to move!',
  requestIsNotPending: 'Request cannot be moved because status is not pending!',

  numIdSequence: 'Sequence Number',
  desInventory: 'Inventory Description',
  statusInventory: 'Status Inventory',
  userCodeResponsible: 'Responsible',
  approvalManager: 'Approval Manager',
  assetWritteOff: 'Considers Inventory OverDue',
  lockMovement: 'Locked Movement',
  assetInventoryOverDue: 'Considers Inventory OverDue',
  sendTermManager: 'Send Terms Manager',
  sendTerm: 'Send Terms '








};
