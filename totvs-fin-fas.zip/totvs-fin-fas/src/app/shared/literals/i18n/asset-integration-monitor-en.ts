export const assetIntegrationMonitorEn = {
  assetIntegrationMonitor: 'Asset Integration Monitor',
  integrationMonitor: 'Integration Monitor',
  inventoryActive: 'Inventory Active',
  inventory: 'Inventory',
  notifications: 'Notifications',
  generalParams: 'General Parameters',
  executionServer: 'RPW Server',
  code: 'Code',
  name: 'Description',
  admin: 'Administrator',
  monitor: 'Monitor',
  return: 'Return',
  requestMovement: 'Request Movement',
  sameTypeRequest: 'Only select requests of the same type to move!',
  requestIsNotPending: 'Request cannot be moved because status is not pending!'
};
