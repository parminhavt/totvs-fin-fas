export const assetIntegrationMonitorPt = {
  assetIntegrationMonitor: 'Monitor de Integração Ativo Fixo',
  integrationMonitor: 'Monitor de Integração',
  inventoryActive: 'Inventário Ativo',
  notifications: 'Notificações',
  generalParams: 'Parâmetros Gerais',
  executionServer: 'Servidor RPW',
  code: 'Código',
  name: 'Descrição',
  admin: 'Administrador',
  monitor: 'Monitor',
  requestMovement: 'Movimentar Solicitações',
  sameTypeRequest: 'Selecione apenas solicitações do mesmo tipo para movimentar!',
  requestIsNotPending: 'Solicitação não pode ser movimentada pois o status não está Pendente!'
};
