import { Component } from '@angular/core';
//import { I18nService } from '@totvs-frame-datasul/dts-fnd-utils';
import { version, dependencies, git, name } from '../../package.json';
import { PoI18nService, PoMenuItem } from '@po-ui/ng-components';
import { Router } from '@angular/router';
import { TranslateService } from 'dts-backoffice-util';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})


  export class AppComponent {
    menus = [
        { label: 'Usuário Universal', link: './universalUser' },
        { label: 'Monitor Ativos', link: './assetMonitor' }
    ];

    constructor(poI18nService: PoI18nService) {
        poI18nService.setLanguage(
            TranslateService.getCurrentLanguage()
        );
    }
    displayVersions(): void {
      console.log('App:', name);
      console.log('Git Info:', git);
      console.log('Versão do App:', version);
      console.log('Dependencias:');
      Object.keys(dependencies).forEach((key) => console.log(' - ', key, ':', dependencies[key]));
    }
}
 /* constructor(    
    private router: Router,
    poI18nService: PoI18nService) {
    this.displayVersions();
    poI18nService.setLanguage(
        localStorage.getItem('user.language') || navigator.language
    );
  }*/

