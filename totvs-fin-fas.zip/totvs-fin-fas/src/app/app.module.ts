import { ParamMonitorService } from './shared/services/param-monitor.service';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PoI18nConfig, PoI18nModule, PoModule } from '@po-ui/ng-components';
import { RouterModule } from '@angular/router';



import { generalEn } from './shared/literals/i18n/general-en';
import { generalEs } from './shared/literals/i18n/general-es';
import { generalPt } from './shared/literals/i18n/general-pt';
import { BreadcrumbControlService, DtsBackofficeUtilsModule, MenuDatasulService } from 'dts-backoffice-util';


import { assetInventoryActiveEs } from './shared/literals/i18n/asset-inventory-active-es';
import { assetInventoryActiveEn } from './shared/literals/i18n/asset-inventory-active-en';
import { assetInventoryActivePt } from './shared/literals/i18n/asset-inventory-active-pt';

import { assetInventoryActiveDetailPt } from './shared/literals/i18n/asset-inventory-active-detail-pt';
import { assetInventoryActiveDetailEn } from './shared/literals/i18n/asset-inventory-active-detail-en';
import { assetInventoryActiveDetailEs } from './shared/literals/i18n/asset-inventory-active-detail-es';


import { assetIntegrationMonitorEs } from './shared/literals/i18n/asset-integration-monitor-es';
import { assetIntegrationMonitorEn } from './shared/literals/i18n/asset-integration-monitor-en';
import { assetIntegrationMonitorPt } from './shared/literals/i18n/asset-integration-monitor-pt';
import { assetIntegrationMonitorDetailPt } from './shared/literals/i18n/asset-integration-monitor-detail-pt';
import { assetIntegrationMonitorDetailEn } from './shared/literals/i18n/asset-integration-monitor-detail-en';
import { assetIntegrationMonitorDetailEs } from './shared/literals/i18n/asset-integration-monitor-detail-es';
import { RpwService } from './shared/services/rpw.service';
import { assetIntegrationMonitorRetirementEn } from './shared/literals/i18n/asset-integration-monitor-retirement-en';
import { assetIntegrationMonitorRetirementPt } from './shared/literals/i18n/asset-integration-monitor-retirement-pt';
import { assetIntegrationMonitorRetirementEs } from './shared/literals/i18n/asset-integration-monitor-retirement-es';
import { assetIntegrationMonitorTransferEn } from './shared/literals/i18n/asset-integration-monitor-transfer-en';
import { assetIntegrationMonitorTransferPt } from './shared/literals/i18n/asset-integration-monitor-transfer-pt';
import { assetIntegrationMonitorTransferEs } from './shared/literals/i18n/asset-integration-monitor-transfer-es';
import { assetMonitorPt } from './shared/literals/i18n/asset-monitor-pt';
import { assetMonitorEn } from './shared/literals/i18n/asset-monitor-en';
import { assetMonitorEs } from './shared/literals/i18n/asset-monitor-es';




const i18nConfig: PoI18nConfig = {
  default: {
      context: 'general',
      cache: true,
      language: 'pt-BR'
  },
  contexts: {
      general: {
          'pt': generalPt,
          'pt-BR': generalPt,
          'en': generalEn,
          'en-US': generalEn,
          'es': generalEs
      },
      assetMonitor: {
        'pt': assetMonitorPt,
          'pt-BR': assetMonitorPt,
        'en': assetMonitorEn,
          'en-US': assetMonitorEn,
        'es': assetMonitorEs
      },
      assetInventoryActive: {
        'pt': assetInventoryActivePt,
          'pt-BR': assetInventoryActivePt,
        'en': assetInventoryActiveEn,
          'en-US': assetInventoryActiveEn,
        'es': assetInventoryActiveEs
      },
      assetInventoryActiveDetail: {
        'pt': assetInventoryActiveDetailPt,
          'pt-BR': assetInventoryActiveDetailPt,
          'en': assetInventoryActiveDetailEn,
          'en-US': assetInventoryActiveDetailEn,
          'es': assetInventoryActiveDetailEs
      },
      assetIntegrationMonitor: {
        'pt': assetIntegrationMonitorPt,
          'pt-BR': assetIntegrationMonitorPt,
          'en': assetIntegrationMonitorEn,
          'en-US': assetIntegrationMonitorEn,
          'es': assetIntegrationMonitorEs
      },
      assetIntegrationMonitorDetail: {
        'pt': assetIntegrationMonitorDetailPt,
          'pt-BR': assetIntegrationMonitorDetailPt,
          'en': assetIntegrationMonitorDetailEn,
          'en-US': assetIntegrationMonitorDetailEn,
          'es': assetIntegrationMonitorDetailEs
      },
      assetIntegrationMonitorRetirement: {
        'pt': assetIntegrationMonitorRetirementPt,
          'pt-BR': assetIntegrationMonitorRetirementPt,
          'en': assetIntegrationMonitorRetirementEn,
          'en-US': assetIntegrationMonitorRetirementEn,
          'es': assetIntegrationMonitorRetirementEs
      },
      assetIntegrationMonitorTransfer: {
        'pt': assetIntegrationMonitorTransferPt,
          'pt-BR': assetIntegrationMonitorTransferPt,
          'en': assetIntegrationMonitorTransferEn,
          'en-US': assetIntegrationMonitorTransferEn,
          'es': assetIntegrationMonitorTransferEs
      },
    }
  };

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    PoModule,
    CommonModule,
    FormsModule,
    AppRoutingModule,
    DtsBackofficeUtilsModule.forRoot(),
    PoI18nModule.config(i18nConfig)
  ],
  providers: [
    MenuDatasulService,
    BreadcrumbControlService,
    RpwService,
    ParamMonitorService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
