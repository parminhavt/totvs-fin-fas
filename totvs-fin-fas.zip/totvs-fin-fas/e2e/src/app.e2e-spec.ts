/*import { AppPage } from './app.po';

describe('totvs-fin-fas App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  it('should display welcome message', () => {
    // page.navigateTo();
    // expect(page.getTitleText()).toEqual('totvs-fin-fas app is running!');
  });
});*/
